
(function(l, i, v, e) { v = l.createElement(i); v.async = 1; v.src = '//' + (location.host || 'localhost').split(':')[0] + ':35729/livereload.js?snipver=1'; e = l.getElementsByTagName(i)[0]; e.parentNode.insertBefore(v, e)})(document, 'script');
var app = (function () {
    'use strict';

    function noop() { }
    function assign(tar, src) {
        // @ts-ignore
        for (const k in src)
            tar[k] = src[k];
        return tar;
    }
    function add_location(element, file, line, column, char) {
        element.__svelte_meta = {
            loc: { file, line, column, char }
        };
    }
    function run(fn) {
        return fn();
    }
    function blank_object() {
        return Object.create(null);
    }
    function run_all(fns) {
        fns.forEach(run);
    }
    function is_function(thing) {
        return typeof thing === 'function';
    }
    function safe_not_equal(a, b) {
        return a != a ? b == b : a !== b || ((a && typeof a === 'object') || typeof a === 'function');
    }
    function validate_store(store, name) {
        if (!store || typeof store.subscribe !== 'function') {
            throw new Error(`'${name}' is not a store with a 'subscribe' method`);
        }
    }
    function subscribe(component, store, callback) {
        const unsub = store.subscribe(callback);
        component.$$.on_destroy.push(unsub.unsubscribe
            ? () => unsub.unsubscribe()
            : unsub);
    }
    function create_slot(definition, ctx, fn) {
        if (definition) {
            const slot_ctx = get_slot_context(definition, ctx, fn);
            return definition[0](slot_ctx);
        }
    }
    function get_slot_context(definition, ctx, fn) {
        return definition[1]
            ? assign({}, assign(ctx.$$scope.ctx, definition[1](fn ? fn(ctx) : {})))
            : ctx.$$scope.ctx;
    }
    function get_slot_changes(definition, ctx, changed, fn) {
        return definition[1]
            ? assign({}, assign(ctx.$$scope.changed || {}, definition[1](fn ? fn(changed) : {})))
            : ctx.$$scope.changed || {};
    }
    const is_client = typeof window !== 'undefined';
    let now = is_client
        ? () => window.performance.now()
        : () => Date.now();
    let raf = is_client ? requestAnimationFrame : noop;

    const tasks = new Set();
    let running = false;
    function run_tasks() {
        tasks.forEach(task => {
            if (!task[0](now())) {
                tasks.delete(task);
                task[1]();
            }
        });
        running = tasks.size > 0;
        if (running)
            raf(run_tasks);
    }
    function loop(fn) {
        let task;
        if (!running) {
            running = true;
            raf(run_tasks);
        }
        return {
            promise: new Promise(fulfil => {
                tasks.add(task = [fn, fulfil]);
            }),
            abort() {
                tasks.delete(task);
            }
        };
    }

    function append(target, node) {
        target.appendChild(node);
    }
    function insert(target, node, anchor) {
        target.insertBefore(node, anchor || null);
    }
    function detach(node) {
        node.parentNode.removeChild(node);
    }
    function destroy_each(iterations, detaching) {
        for (let i = 0; i < iterations.length; i += 1) {
            if (iterations[i])
                iterations[i].d(detaching);
        }
    }
    function element(name) {
        return document.createElement(name);
    }
    function text(data) {
        return document.createTextNode(data);
    }
    function space() {
        return text(' ');
    }
    function empty() {
        return text('');
    }
    function listen(node, event, handler, options) {
        node.addEventListener(event, handler, options);
        return () => node.removeEventListener(event, handler, options);
    }
    function attr(node, attribute, value) {
        if (value == null)
            node.removeAttribute(attribute);
        else
            node.setAttribute(attribute, value);
    }
    function children(element) {
        return Array.from(element.childNodes);
    }
    function set_data(text, data) {
        data = '' + data;
        if (text.data !== data)
            text.data = data;
    }
    function set_style(node, key, value) {
        node.style.setProperty(key, value);
    }
    function toggle_class(element, name, toggle) {
        element.classList[toggle ? 'add' : 'remove'](name);
    }

    let current_component;
    function set_current_component(component) {
        current_component = component;
    }
    function get_current_component() {
        if (!current_component)
            throw new Error(`Function called outside component initialization`);
        return current_component;
    }
    function beforeUpdate(fn) {
        get_current_component().$$.before_render.push(fn);
    }
    function onMount(fn) {
        get_current_component().$$.on_mount.push(fn);
    }

    const dirty_components = [];
    const resolved_promise = Promise.resolve();
    let update_scheduled = false;
    const binding_callbacks = [];
    const render_callbacks = [];
    const flush_callbacks = [];
    function schedule_update() {
        if (!update_scheduled) {
            update_scheduled = true;
            resolved_promise.then(flush);
        }
    }
    function add_binding_callback(fn) {
        binding_callbacks.push(fn);
    }
    function add_render_callback(fn) {
        render_callbacks.push(fn);
    }
    function flush() {
        const seen_callbacks = new Set();
        do {
            // first, call beforeUpdate functions
            // and update components
            while (dirty_components.length) {
                const component = dirty_components.shift();
                set_current_component(component);
                update(component.$$);
            }
            while (binding_callbacks.length)
                binding_callbacks.shift()();
            // then, once components are updated, call
            // afterUpdate functions. This may cause
            // subsequent updates...
            while (render_callbacks.length) {
                const callback = render_callbacks.pop();
                if (!seen_callbacks.has(callback)) {
                    callback();
                    // ...so guard against infinite loops
                    seen_callbacks.add(callback);
                }
            }
        } while (dirty_components.length);
        while (flush_callbacks.length) {
            flush_callbacks.pop()();
        }
        update_scheduled = false;
    }
    function update($$) {
        if ($$.fragment) {
            $$.update($$.dirty);
            run_all($$.before_render);
            $$.fragment.p($$.dirty, $$.ctx);
            $$.dirty = null;
            $$.after_render.forEach(add_render_callback);
        }
    }
    let outros;
    function group_outros() {
        outros = {
            remaining: 0,
            callbacks: []
        };
    }
    function check_outros() {
        if (!outros.remaining) {
            run_all(outros.callbacks);
        }
    }
    function on_outro(callback) {
        outros.callbacks.push(callback);
    }
    function mount_component(component, target, anchor) {
        const { fragment, on_mount, on_destroy, after_render } = component.$$;
        fragment.m(target, anchor);
        // onMount happens after the initial afterUpdate. Because
        // afterUpdate callbacks happen in reverse order (inner first)
        // we schedule onMount callbacks before afterUpdate callbacks
        add_render_callback(() => {
            const new_on_destroy = on_mount.map(run).filter(is_function);
            if (on_destroy) {
                on_destroy.push(...new_on_destroy);
            }
            else {
                // Edge case - component was destroyed immediately,
                // most likely as a result of a binding initialising
                run_all(new_on_destroy);
            }
            component.$$.on_mount = [];
        });
        after_render.forEach(add_render_callback);
    }
    function destroy(component, detaching) {
        if (component.$$) {
            run_all(component.$$.on_destroy);
            component.$$.fragment.d(detaching);
            // TODO null out other refs, including component.$$ (but need to
            // preserve final state?)
            component.$$.on_destroy = component.$$.fragment = null;
            component.$$.ctx = {};
        }
    }
    function make_dirty(component, key) {
        if (!component.$$.dirty) {
            dirty_components.push(component);
            schedule_update();
            component.$$.dirty = blank_object();
        }
        component.$$.dirty[key] = true;
    }
    function init(component, options, instance, create_fragment, not_equal$$1, prop_names) {
        const parent_component = current_component;
        set_current_component(component);
        const props = options.props || {};
        const $$ = component.$$ = {
            fragment: null,
            ctx: null,
            // state
            props: prop_names,
            update: noop,
            not_equal: not_equal$$1,
            bound: blank_object(),
            // lifecycle
            on_mount: [],
            on_destroy: [],
            before_render: [],
            after_render: [],
            context: new Map(parent_component ? parent_component.$$.context : []),
            // everything else
            callbacks: blank_object(),
            dirty: null
        };
        let ready = false;
        $$.ctx = instance
            ? instance(component, props, (key, value) => {
                if ($$.ctx && not_equal$$1($$.ctx[key], $$.ctx[key] = value)) {
                    if ($$.bound[key])
                        $$.bound[key](value);
                    if (ready)
                        make_dirty(component, key);
                }
            })
            : props;
        $$.update();
        ready = true;
        run_all($$.before_render);
        $$.fragment = create_fragment($$.ctx);
        if (options.target) {
            if (options.hydrate) {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                $$.fragment.l(children(options.target));
            }
            else {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                $$.fragment.c();
            }
            if (options.intro && component.$$.fragment.i)
                component.$$.fragment.i();
            mount_component(component, options.target, options.anchor);
            flush();
        }
        set_current_component(parent_component);
    }
    class SvelteComponent {
        $destroy() {
            destroy(this, true);
            this.$destroy = noop;
        }
        $on(type, callback) {
            const callbacks = (this.$$.callbacks[type] || (this.$$.callbacks[type] = []));
            callbacks.push(callback);
            return () => {
                const index = callbacks.indexOf(callback);
                if (index !== -1)
                    callbacks.splice(index, 1);
            };
        }
        $set() {
            // overridden by instance, if it has props
        }
    }
    class SvelteComponentDev extends SvelteComponent {
        constructor(options) {
            if (!options || (!options.target && !options.$$inline)) {
                throw new Error(`'target' is a required option`);
            }
            super();
        }
        $destroy() {
            super.$destroy();
            this.$destroy = () => {
                console.warn(`Component was already destroyed`); // eslint-disable-line no-console
            };
        }
    }

    /**
     * Create a `Writable` store that allows both updating and reading by subscription.
     * @param {*=}value initial value
     * @param {StartStopNotifier=}start start and stop notifications for subscriptions
     */
    function writable(value, start = noop) {
        let stop;
        const subscribers = [];
        function set(new_value) {
            if (safe_not_equal(value, new_value)) {
                value = new_value;
                if (!stop) {
                    return; // not ready
                }
                subscribers.forEach((s) => s[1]());
                subscribers.forEach((s) => s[0](value));
            }
        }
        function update(fn) {
            set(fn(value));
        }
        function subscribe(run, invalidate = noop) {
            const subscriber = [run, invalidate];
            subscribers.push(subscriber);
            if (subscribers.length === 1) {
                stop = start(set) || noop;
            }
            run(value);
            return () => {
                const index = subscribers.indexOf(subscriber);
                if (index !== -1) {
                    subscribers.splice(index, 1);
                }
                if (subscribers.length === 0) {
                    stop();
                }
            };
        }
        return { set, update, subscribe };
    }
    /**
     * Get the current value from a store by subscribing and immediately unsubscribing.
     * @param store readable
     */
    function get(store) {
        let value;
        store.subscribe((_) => value = _)();
        return value;
    }

    var obj;
    var NOTHING = typeof Symbol !== "undefined" ? Symbol("immer-nothing") : ( obj = {}, obj["immer-nothing"] = true, obj );
    var DRAFTABLE = typeof Symbol !== "undefined" && Symbol.for ? Symbol.for("immer-draftable") : "__$immer_draftable";
    var DRAFT_STATE = typeof Symbol !== "undefined" && Symbol.for ? Symbol.for("immer-state") : "__$immer_state";
    function isDraft(value) {
      return !!value && !!value[DRAFT_STATE];
    }
    function isDraftable(value) {
      if (!value || typeof value !== "object") { return false; }
      if (Array.isArray(value)) { return true; }
      var proto = Object.getPrototypeOf(value);
      if (!proto || proto === Object.prototype) { return true; }
      return !!value[DRAFTABLE] || !!value.constructor[DRAFTABLE];
    }
    var assign$1 = Object.assign || function assign(target, value) {
      for (var key in value) {
        if (has(value, key)) {
          target[key] = value[key];
        }
      }

      return target;
    };
    var ownKeys = typeof Reflect !== "undefined" && Reflect.ownKeys ? Reflect.ownKeys : typeof Object.getOwnPropertySymbols !== "undefined" ? function (obj) { return Object.getOwnPropertyNames(obj).concat(Object.getOwnPropertySymbols(obj)); } : Object.getOwnPropertyNames;
    function shallowCopy(base, invokeGetters) {
      if ( invokeGetters === void 0 ) invokeGetters = false;

      if (Array.isArray(base)) { return base.slice(); }
      var clone = Object.create(Object.getPrototypeOf(base));
      ownKeys(base).forEach(function (key) {
        if (key === DRAFT_STATE) {
          return; // Never copy over draft state.
        }

        var desc = Object.getOwnPropertyDescriptor(base, key);
        var value = desc.value;

        if (desc.get) {
          if (!invokeGetters) {
            throw new Error("Immer drafts cannot have computed properties");
          }

          value = desc.get.call(base);
        }

        if (desc.enumerable) {
          clone[key] = value;
        } else {
          Object.defineProperty(clone, key, {
            value: value,
            writable: true,
            configurable: true
          });
        }
      });
      return clone;
    }
    function each(value, cb) {
      if (Array.isArray(value)) {
        for (var i = 0; i < value.length; i++) { cb(i, value[i], value); }
      } else {
        ownKeys(value).forEach(function (key) { return cb(key, value[key], value); });
      }
    }
    function isEnumerable(base, prop) {
      var desc = Object.getOwnPropertyDescriptor(base, prop);
      return !!desc && desc.enumerable;
    }
    function has(thing, prop) {
      return Object.prototype.hasOwnProperty.call(thing, prop);
    }
    function is(x, y) {
      // From: https://github.com/facebook/fbjs/blob/c69904a511b900266935168223063dd8772dfc40/packages/fbjs/src/core/shallowEqual.js
      if (x === y) {
        return x !== 0 || 1 / x === 1 / y;
      } else {
        return x !== x && y !== y;
      }
    }

    /** Each scope represents a `produce` call. */

    var ImmerScope = function ImmerScope(parent) {
      this.drafts = [];
      this.parent = parent; // Whenever the modified draft contains a draft from another scope, we
      // need to prevent auto-freezing so the unowned draft can be finalized.

      this.canAutoFreeze = true; // To avoid prototype lookups:

      this.patches = null;
    };

    ImmerScope.prototype.usePatches = function usePatches (patchListener) {
      if (patchListener) {
        this.patches = [];
        this.inversePatches = [];
        this.patchListener = patchListener;
      }
    };

    ImmerScope.prototype.revoke = function revoke$1 () {
      this.leave();
      this.drafts.forEach(revoke);
      this.drafts = null; // Make draft-related methods throw.
    };

    ImmerScope.prototype.leave = function leave () {
      if (this === ImmerScope.current) {
        ImmerScope.current = this.parent;
      }
    };
    ImmerScope.current = null;

    ImmerScope.enter = function () {
      return this.current = new ImmerScope(this.current);
    };

    function revoke(draft) {
      draft[DRAFT_STATE].revoke();
    }

    // but share them all instead

    var descriptors = {};
    function willFinalize(scope, result, isReplaced) {
      scope.drafts.forEach(function (draft) {
        draft[DRAFT_STATE].finalizing = true;
      });

      if (!isReplaced) {
        if (scope.patches) {
          markChangesRecursively(scope.drafts[0]);
        } // This is faster when we don't care about which attributes changed.


        markChangesSweep(scope.drafts);
      } // When a child draft is returned, look for changes.
      else if (isDraft(result) && result[DRAFT_STATE].scope === scope) {
          markChangesSweep(scope.drafts);
        }
    }
    function createProxy(base, parent) {
      var isArray = Array.isArray(base);
      var draft = clonePotentialDraft(base);
      each(draft, function (prop) {
        proxyProperty(draft, prop, isArray || isEnumerable(base, prop));
      }); // See "proxy.js" for property documentation.

      var scope = parent ? parent.scope : ImmerScope.current;
      var state = {
        scope: scope,
        modified: false,
        finalizing: false,
        // es5 only
        finalized: false,
        assigned: {},
        parent: parent,
        base: base,
        draft: draft,
        copy: null,
        revoke: revoke$1,
        revoked: false // es5 only

      };
      createHiddenProperty(draft, DRAFT_STATE, state);
      scope.drafts.push(draft);
      return draft;
    }

    function revoke$1() {
      this.revoked = true;
    }

    function source(state) {
      return state.copy || state.base;
    } // Access a property without creating an Immer draft.


    function peek(draft, prop) {
      var state = draft[DRAFT_STATE];

      if (state && !state.finalizing) {
        state.finalizing = true;
        var value = draft[prop];
        state.finalizing = false;
        return value;
      }

      return draft[prop];
    }

    function get$1(state, prop) {
      assertUnrevoked(state);
      var value = peek(source(state), prop);
      if (state.finalizing) { return value; } // Create a draft if the value is unmodified.

      if (value === peek(state.base, prop) && isDraftable(value)) {
        prepareCopy(state);
        return state.copy[prop] = createProxy(value, state);
      }

      return value;
    }

    function set(state, prop, value) {
      assertUnrevoked(state);
      state.assigned[prop] = true;

      if (!state.modified) {
        if (is(value, peek(source(state), prop))) { return; }
        markChanged(state);
        prepareCopy(state);
      }

      state.copy[prop] = value;
    }

    function markChanged(state) {
      if (!state.modified) {
        state.modified = true;
        if (state.parent) { markChanged(state.parent); }
      }
    }

    function prepareCopy(state) {
      if (!state.copy) { state.copy = clonePotentialDraft(state.base); }
    }

    function clonePotentialDraft(base) {
      var state = base && base[DRAFT_STATE];

      if (state) {
        state.finalizing = true;
        var draft = shallowCopy(state.draft, true);
        state.finalizing = false;
        return draft;
      }

      return shallowCopy(base);
    }

    function proxyProperty(draft, prop, enumerable) {
      var desc = descriptors[prop];

      if (desc) {
        desc.enumerable = enumerable;
      } else {
        descriptors[prop] = desc = {
          configurable: true,
          enumerable: enumerable,

          get: function get$1$1() {
            return get$1(this[DRAFT_STATE], prop);
          },

          set: function set$1(value) {
            set(this[DRAFT_STATE], prop, value);
          }

        };
      }

      Object.defineProperty(draft, prop, desc);
    }

    function assertUnrevoked(state) {
      if (state.revoked === true) { throw new Error("Cannot use a proxy that has been revoked. Did you pass an object from inside an immer function to an async process? " + JSON.stringify(source(state))); }
    } // This looks expensive, but only proxies are visited, and only objects without known changes are scanned.


    function markChangesSweep(drafts) {
      // The natural order of drafts in the `scope` array is based on when they
      // were accessed. By processing drafts in reverse natural order, we have a
      // better chance of processing leaf nodes first. When a leaf node is known to
      // have changed, we can avoid any traversal of its ancestor nodes.
      for (var i = drafts.length - 1; i >= 0; i--) {
        var state = drafts[i][DRAFT_STATE];

        if (!state.modified) {
          if (Array.isArray(state.base)) {
            if (hasArrayChanges(state)) { markChanged(state); }
          } else if (hasObjectChanges(state)) { markChanged(state); }
        }
      }
    }

    function markChangesRecursively(object) {
      if (!object || typeof object !== "object") { return; }
      var state = object[DRAFT_STATE];
      if (!state) { return; }
      var base = state.base;
      var draft = state.draft;
      var assigned = state.assigned;

      if (!Array.isArray(object)) {
        // Look for added keys.
        Object.keys(draft).forEach(function (key) {
          // The `undefined` check is a fast path for pre-existing keys.
          if (base[key] === undefined && !has(base, key)) {
            assigned[key] = true;
            markChanged(state);
          } else if (!assigned[key]) {
            // Only untouched properties trigger recursion.
            markChangesRecursively(draft[key]);
          }
        }); // Look for removed keys.

        Object.keys(base).forEach(function (key) {
          // The `undefined` check is a fast path for pre-existing keys.
          if (draft[key] === undefined && !has(draft, key)) {
            assigned[key] = false;
            markChanged(state);
          }
        });
      } else if (hasArrayChanges(state)) {
        markChanged(state);
        assigned.length = true;

        if (draft.length < base.length) {
          for (var i = draft.length; i < base.length; i++) { assigned[i] = false; }
        } else {
          for (var i$1 = base.length; i$1 < draft.length; i$1++) { assigned[i$1] = true; }
        }

        for (var i$2 = 0; i$2 < draft.length; i$2++) {
          // Only untouched indices trigger recursion.
          if (assigned[i$2] === undefined) { markChangesRecursively(draft[i$2]); }
        }
      }
    }

    function hasObjectChanges(state) {
      var base = state.base;
      var draft = state.draft; // Search for added keys and changed keys. Start at the back, because
      // non-numeric keys are ordered by time of definition on the object.

      var keys = Object.keys(draft);

      for (var i = keys.length - 1; i >= 0; i--) {
        var key = keys[i];
        var baseValue = base[key]; // The `undefined` check is a fast path for pre-existing keys.

        if (baseValue === undefined && !has(base, key)) {
          return true;
        } // Once a base key is deleted, future changes go undetected, because its
        // descriptor is erased. This branch detects any missed changes.
        else {
            var value = draft[key];
            var state$1 = value && value[DRAFT_STATE];

            if (state$1 ? state$1.base !== baseValue : !is(value, baseValue)) {
              return true;
            }
          }
      } // At this point, no keys were added or changed.
      // Compare key count to determine if keys were deleted.


      return keys.length !== Object.keys(base).length;
    }

    function hasArrayChanges(state) {
      var draft = state.draft;
      if (draft.length !== state.base.length) { return true; } // See #116
      // If we first shorten the length, our array interceptors will be removed.
      // If after that new items are added, result in the same original length,
      // those last items will have no intercepting property.
      // So if there is no own descriptor on the last position, we know that items were removed and added
      // N.B.: splice, unshift, etc only shift values around, but not prop descriptors, so we only have to check
      // the last one

      var descriptor = Object.getOwnPropertyDescriptor(draft, draft.length - 1); // descriptor can be null, but only for newly created sparse arrays, eg. new Array(10)

      if (descriptor && !descriptor.get) { return true; } // For all other cases, we don't have to compare, as they would have been picked up by the index setters

      return false;
    }

    function createHiddenProperty(target, prop, value) {
      Object.defineProperty(target, prop, {
        value: value,
        enumerable: false,
        writable: true
      });
    }

    var legacyProxy = /*#__PURE__*/Object.freeze({
        willFinalize: willFinalize,
        createProxy: createProxy
    });

    function willFinalize$1() {}
    function createProxy$1(base, parent) {
      var scope = parent ? parent.scope : ImmerScope.current;
      var state = {
        // Track which produce call this is associated with.
        scope: scope,
        // True for both shallow and deep changes.
        modified: false,
        // Used during finalization.
        finalized: false,
        // Track which properties have been assigned (true) or deleted (false).
        assigned: {},
        // The parent draft state.
        parent: parent,
        // The base state.
        base: base,
        // The base proxy.
        draft: null,
        // Any property proxies.
        drafts: {},
        // The base copy with any updated values.
        copy: null,
        // Called by the `produce` function.
        revoke: null
      };
      var ref = Array.isArray(base) ? // [state] is used for arrays, to make sure the proxy is array-ish and not violate invariants,
      // although state itself is an object
      Proxy.revocable([state], arrayTraps) : Proxy.revocable(state, objectTraps);
      var revoke = ref.revoke;
      var proxy = ref.proxy;
      state.draft = proxy;
      state.revoke = revoke;
      scope.drafts.push(proxy);
      return proxy;
    }
    var objectTraps = {
      get: get$1$1,

      has: function has(target, prop) {
        return prop in source$1(target);
      },

      ownKeys: function ownKeys(target) {
        return Reflect.ownKeys(source$1(target));
      },

      set: set$1,
      deleteProperty: deleteProperty,
      getOwnPropertyDescriptor: getOwnPropertyDescriptor,

      defineProperty: function defineProperty() {
        throw new Error("Object.defineProperty() cannot be used on an Immer draft"); // prettier-ignore
      },

      getPrototypeOf: function getPrototypeOf(target) {
        return Object.getPrototypeOf(target.base);
      },

      setPrototypeOf: function setPrototypeOf() {
        throw new Error("Object.setPrototypeOf() cannot be used on an Immer draft"); // prettier-ignore
      }

    };
    var arrayTraps = {};
    each(objectTraps, function (key, fn) {
      arrayTraps[key] = function () {
        arguments[0] = arguments[0][0];
        return fn.apply(this, arguments);
      };
    });

    arrayTraps.deleteProperty = function (state, prop) {
      if (isNaN(parseInt(prop))) {
        throw new Error("Immer only supports deleting array indices"); // prettier-ignore
      }

      return objectTraps.deleteProperty.call(this, state[0], prop);
    };

    arrayTraps.set = function (state, prop, value) {
      if (prop !== "length" && isNaN(parseInt(prop))) {
        throw new Error("Immer only supports setting array indices and the 'length' property"); // prettier-ignore
      }

      return objectTraps.set.call(this, state[0], prop, value);
    }; // returns the object we should be reading the current value from, which is base, until some change has been made


    function source$1(state) {
      return state.copy || state.base;
    } // Access a property without creating an Immer draft.


    function peek$1(draft, prop) {
      var state = draft[DRAFT_STATE];
      var desc = Reflect.getOwnPropertyDescriptor(state ? source$1(state) : draft, prop);
      return desc && desc.value;
    }

    function get$1$1(state, prop) {
      if (prop === DRAFT_STATE) { return state; }
      var drafts = state.drafts; // Check for existing draft in unmodified state.

      if (!state.modified && has(drafts, prop)) {
        return drafts[prop];
      }

      var value = source$1(state)[prop];

      if (state.finalized || !isDraftable(value)) {
        return value;
      } // Check for existing draft in modified state.


      if (state.modified) {
        // Assigned values are never drafted. This catches any drafts we created, too.
        if (value !== peek$1(state.base, prop)) { return value; } // Store drafts on the copy (when one exists).

        drafts = state.copy;
      }

      return drafts[prop] = createProxy$1(value, state);
    }

    function set$1(state, prop, value) {
      if (!state.modified) {
        var baseValue = peek$1(state.base, prop); // Optimize based on value's truthiness. Truthy values are guaranteed to
        // never be undefined, so we can avoid the `in` operator. Lastly, truthy
        // values may be drafts, but falsy values are never drafts.

        var isUnchanged = value ? is(baseValue, value) || value === state.drafts[prop] : is(baseValue, value) && prop in state.base;
        if (isUnchanged) { return true; }
        markChanged$1(state);
      }

      state.assigned[prop] = true;
      state.copy[prop] = value;
      return true;
    }

    function deleteProperty(state, prop) {
      // The `undefined` check is a fast path for pre-existing keys.
      if (peek$1(state.base, prop) !== undefined || prop in state.base) {
        state.assigned[prop] = false;
        markChanged$1(state);
      }

      if (state.copy) { delete state.copy[prop]; }
      return true;
    } // Note: We never coerce `desc.value` into an Immer draft, because we can't make
    // the same guarantee in ES5 mode.


    function getOwnPropertyDescriptor(state, prop) {
      var owner = source$1(state);
      var desc = Reflect.getOwnPropertyDescriptor(owner, prop);

      if (desc) {
        desc.writable = true;
        desc.configurable = !Array.isArray(owner) || prop !== "length";
      }

      return desc;
    }

    function markChanged$1(state) {
      if (!state.modified) {
        state.modified = true;
        state.copy = assign$1(shallowCopy(state.base), state.drafts);
        state.drafts = null;
        if (state.parent) { markChanged$1(state.parent); }
      }
    }

    var modernProxy = /*#__PURE__*/Object.freeze({
        willFinalize: willFinalize$1,
        createProxy: createProxy$1
    });

    function generatePatches(state, basePath, patches, inversePatches) {
      Array.isArray(state.base) ? generateArrayPatches(state, basePath, patches, inversePatches) : generateObjectPatches(state, basePath, patches, inversePatches);
    }

    function generateArrayPatches(state, basePath, patches, inversePatches) {
      var assign, assign$1;

      var base = state.base;
      var copy = state.copy;
      var assigned = state.assigned; // Reduce complexity by ensuring `base` is never longer.

      if (copy.length < base.length) {
        (assign = [copy, base], base = assign[0], copy = assign[1]);
        (assign$1 = [inversePatches, patches], patches = assign$1[0], inversePatches = assign$1[1]);
      }

      var delta = copy.length - base.length; // Find the first replaced index.

      var start = 0;

      while (base[start] === copy[start] && start < base.length) {
        ++start;
      } // Find the last replaced index. Search from the end to optimize splice patches.


      var end = base.length;

      while (end > start && base[end - 1] === copy[end + delta - 1]) {
        --end;
      } // Process replaced indices.


      for (var i = start; i < end; ++i) {
        if (assigned[i] && copy[i] !== base[i]) {
          var path = basePath.concat([i]);
          patches.push({
            op: "replace",
            path: path,
            value: copy[i]
          });
          inversePatches.push({
            op: "replace",
            path: path,
            value: base[i]
          });
        }
      }

      var useRemove = end != base.length;
      var replaceCount = patches.length; // Process added indices.

      for (var i$1 = end + delta - 1; i$1 >= end; --i$1) {
        var path$1 = basePath.concat([i$1]);
        patches[replaceCount + i$1 - end] = {
          op: "add",
          path: path$1,
          value: copy[i$1]
        };

        if (useRemove) {
          inversePatches.push({
            op: "remove",
            path: path$1
          });
        }
      } // One "replace" patch reverses all non-splicing "add" patches.


      if (!useRemove) {
        inversePatches.push({
          op: "replace",
          path: basePath.concat(["length"]),
          value: base.length
        });
      }
    }

    function generateObjectPatches(state, basePath, patches, inversePatches) {
      var base = state.base;
      var copy = state.copy;
      each(state.assigned, function (key, assignedValue) {
        var origValue = base[key];
        var value = copy[key];
        var op = !assignedValue ? "remove" : key in base ? "replace" : "add";
        if (origValue === value && op === "replace") { return; }
        var path = basePath.concat(key);
        patches.push(op === "remove" ? {
          op: op,
          path: path
        } : {
          op: op,
          path: path,
          value: value
        });
        inversePatches.push(op === "add" ? {
          op: "remove",
          path: path
        } : op === "remove" ? {
          op: "add",
          path: path,
          value: origValue
        } : {
          op: "replace",
          path: path,
          value: origValue
        });
      });
    }

    function applyPatches(draft, patches) {
      for (var i = 0; i < patches.length; i++) {
        var patch = patches[i];
        var path = patch.path;

        if (path.length === 0 && patch.op === "replace") {
          draft = patch.value;
        } else {
          var base = draft;

          for (var i$1 = 0; i$1 < path.length - 1; i$1++) {
            base = base[path[i$1]];
            if (!base || typeof base !== "object") { throw new Error("Cannot apply patch, path doesn't resolve: " + path.join("/")); } // prettier-ignore
          }

          var key = path[path.length - 1];

          switch (patch.op) {
            case "replace":
              base[key] = patch.value;
              break;

            case "add":
              if (Array.isArray(base)) {
                // TODO: support "foo/-" paths for appending to an array
                base.splice(key, 0, patch.value);
              } else {
                base[key] = patch.value;
              }

              break;

            case "remove":
              if (Array.isArray(base)) {
                base.splice(key, 1);
              } else {
                delete base[key];
              }

              break;

            default:
              throw new Error("Unsupported patch operation: " + patch.op);
          }
        }
      }

      return draft;
    }

    function verifyMinified() {}

    var configDefaults = {
      useProxies: typeof Proxy !== "undefined" && typeof Reflect !== "undefined",
      autoFreeze: typeof process !== "undefined" ? process.env.NODE_ENV !== "production" : verifyMinified.name === "verifyMinified",
      onAssign: null,
      onDelete: null,
      onCopy: null
    };
    var Immer = function Immer(config) {
      assign$1(this, configDefaults, config);
      this.setUseProxies(this.useProxies);
      this.produce = this.produce.bind(this);
    };

    Immer.prototype.produce = function produce (base, recipe, patchListener) {
        var this$1 = this;

      // curried invocation
      if (typeof base === "function" && typeof recipe !== "function") {
        var defaultBase = recipe;
        recipe = base;
        var self = this;
        return function curriedProduce(base) {
            var this$1 = this;
            if ( base === void 0 ) base = defaultBase;
            var args = [], len = arguments.length - 1;
            while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

          return self.produce(base, function (draft) { return recipe.call.apply(recipe, [ this$1, draft ].concat( args )); }); // prettier-ignore
        };
      } // prettier-ignore


      {
        if (typeof recipe !== "function") {
          throw new Error("The first or second argument to `produce` must be a function");
        }

        if (patchListener !== undefined && typeof patchListener !== "function") {
          throw new Error("The third argument to `produce` must be a function or undefined");
        }
      }
      var result; // Only plain objects, arrays, and "immerable classes" are drafted.

      if (isDraftable(base)) {
        var scope = ImmerScope.enter();
        var proxy = this.createProxy(base);
        var hasError = true;

        try {
          result = recipe(proxy);
          hasError = false;
        } finally {
          // finally instead of catch + rethrow better preserves original stack
          if (hasError) { scope.revoke(); }else { scope.leave(); }
        }

        if (result instanceof Promise) {
          return result.then(function (result) {
            scope.usePatches(patchListener);
            return this$1.processResult(result, scope);
          }, function (error) {
            scope.revoke();
            throw error;
          });
        }

        scope.usePatches(patchListener);
        return this.processResult(result, scope);
      } else {
        result = recipe(base);
        if (result === undefined) { return base; }
        return result !== NOTHING ? result : undefined;
      }
    };

    Immer.prototype.createDraft = function createDraft (base) {
      if (!isDraftable(base)) {
        throw new Error("First argument to `createDraft` must be a plain object, an array, or an immerable object"); // prettier-ignore
      }

      var scope = ImmerScope.enter();
      var proxy = this.createProxy(base);
      proxy[DRAFT_STATE].isManual = true;
      scope.leave();
      return proxy;
    };

    Immer.prototype.finishDraft = function finishDraft (draft, patchListener) {
      var state = draft && draft[DRAFT_STATE];

      if (!state || !state.isManual) {
        throw new Error("First argument to `finishDraft` must be a draft returned by `createDraft`"); // prettier-ignore
      }

      if (state.finalized) {
        throw new Error("The given draft is already finalized"); // prettier-ignore
      }

      var scope = state.scope;
      scope.usePatches(patchListener);
      return this.processResult(undefined, scope);
    };

    Immer.prototype.setAutoFreeze = function setAutoFreeze (value) {
      this.autoFreeze = value;
    };

    Immer.prototype.setUseProxies = function setUseProxies (value) {
      this.useProxies = value;
      assign$1(this, value ? modernProxy : legacyProxy);
    };

    Immer.prototype.applyPatches = function applyPatches$1 (base, patches) {
      // Mutate the base state when a draft is passed.
      if (isDraft(base)) {
        return applyPatches(base, patches);
      } // Otherwise, produce a copy of the base state.


      return this.produce(base, function (draft) { return applyPatches(draft, patches); });
    };
    /** @internal */


    Immer.prototype.processResult = function processResult (result, scope) {
      var baseDraft = scope.drafts[0];
      var isReplaced = result !== undefined && result !== baseDraft;
      this.willFinalize(scope, result, isReplaced);

      if (isReplaced) {
        if (baseDraft[DRAFT_STATE].modified) {
          scope.revoke();
          throw new Error("An immer producer returned a new value *and* modified its draft. Either return a new value *or* modify the draft."); // prettier-ignore
        }

        if (isDraftable(result)) {
          // Finalize the result in case it contains (or is) a subset of the draft.
          result = this.finalize(result, null, scope);
        }

        if (scope.patches) {
          scope.patches.push({
            op: "replace",
            path: [],
            value: result
          });
          scope.inversePatches.push({
            op: "replace",
            path: [],
            value: baseDraft[DRAFT_STATE].base
          });
        }
      } else {
        // Finalize the base draft.
        result = this.finalize(baseDraft, [], scope);
      }

      scope.revoke();

      if (scope.patches) {
        scope.patchListener(scope.patches, scope.inversePatches);
      }

      return result !== NOTHING ? result : undefined;
    };
    /**
     * @internal
     * Finalize a draft, returning either the unmodified base state or a modified
     * copy of the base state.
     */


    Immer.prototype.finalize = function finalize (draft, path, scope) {
        var this$1 = this;

      var state = draft[DRAFT_STATE];

      if (!state) {
        if (Object.isFrozen(draft)) { return draft; }
        return this.finalizeTree(draft, null, scope);
      } // Never finalize drafts owned by another scope.


      if (state.scope !== scope) {
        return draft;
      }

      if (!state.modified) {
        return state.base;
      }

      if (!state.finalized) {
        state.finalized = true;
        this.finalizeTree(state.draft, path, scope);

        if (this.onDelete) {
          // The `assigned` object is unreliable with ES5 drafts.
          if (this.useProxies) {
            var assigned = state.assigned;

            for (var prop in assigned) {
              if (!assigned[prop]) { this.onDelete(state, prop); }
            }
          } else {
            var base = state.base;
              var copy = state.copy;
            each(base, function (prop) {
              if (!has(copy, prop)) { this$1.onDelete(state, prop); }
            });
          }
        }

        if (this.onCopy) {
          this.onCopy(state);
        } // At this point, all descendants of `state.copy` have been finalized,
        // so we can be sure that `scope.canAutoFreeze` is accurate.


        if (this.autoFreeze && scope.canAutoFreeze) {
          Object.freeze(state.copy);
        }

        if (path && scope.patches) {
          generatePatches(state, path, scope.patches, scope.inversePatches);
        }
      }

      return state.copy;
    };
    /**
     * @internal
     * Finalize all drafts in the given state tree.
     */


    Immer.prototype.finalizeTree = function finalizeTree (root, rootPath, scope) {
        var this$1 = this;

      var state = root[DRAFT_STATE];

      if (state) {
        if (!this.useProxies) {
          // Create the final copy, with added keys and without deleted keys.
          state.copy = shallowCopy(state.draft, true);
        }

        root = state.copy;
      }

      var needPatches = !!rootPath && !!scope.patches;

      var finalizeProperty = function (prop, value, parent) {
        if (value === parent) {
          throw Error("Immer forbids circular references");
        } // In the `finalizeTree` method, only the `root` object may be a draft.


        var isDraftProp = !!state && parent === root;

        if (isDraft(value)) {
          var path = isDraftProp && needPatches && !state.assigned[prop] ? rootPath.concat(prop) : null; // Drafts owned by `scope` are finalized here.

          value = this$1.finalize(value, path, scope); // Drafts from another scope must prevent auto-freezing.

          if (isDraft(value)) {
            scope.canAutoFreeze = false;
          } // Preserve non-enumerable properties.


          if (Array.isArray(parent) || isEnumerable(parent, prop)) {
            parent[prop] = value;
          } else {
            Object.defineProperty(parent, prop, {
              value: value
            });
          } // Unchanged drafts are never passed to the `onAssign` hook.


          if (isDraftProp && value === state.base[prop]) { return; }
        } // Unchanged draft properties are ignored.
        else if (isDraftProp && is(value, state.base[prop])) {
            return;
          } // Search new objects for unfinalized drafts. Frozen objects should never contain drafts.
          else if (isDraftable(value) && !Object.isFrozen(value)) {
              each(value, finalizeProperty);
            }

        if (isDraftProp && this$1.onAssign) {
          this$1.onAssign(state, prop, value);
        }
      };

      each(root, finalizeProperty);
      return root;
    };

    var immer = new Immer();
    /**
     * The `produce` function takes a value and a "recipe function" (whose
     * return value often depends on the base state). The recipe function is
     * free to mutate its first argument however it wants. All mutations are
     * only ever applied to a __copy__ of the base state.
     *
     * Pass only a function to create a "curried producer" which relieves you
     * from passing the recipe function every time.
     *
     * Only plain objects and arrays are made mutable. All other objects are
     * considered uncopyable.
     *
     * Note: This function is __bound__ to its `Immer` instance.
     *
     * @param {any} base - the initial state
     * @param {Function} producer - function that receives a proxy of the base state as first argument and which can be freely modified
     * @param {Function} patchListener - optional function that will be called with all the patches produced here
     * @returns {any} a new state, or the initial state if nothing was modified
     */

    var produce = immer.produce;
    /**
     * Pass true to automatically freeze all copies created by Immer.
     *
     * By default, auto-freezing is disabled in production.
     */

    var setAutoFreeze = immer.setAutoFreeze.bind(immer);
    /**
     * Pass true to use the ES2015 `Proxy` class when creating drafts, which is
     * always faster than using ES5 proxies.
     *
     * By default, feature detection is used, so calling this is rarely necessary.
     */

    var setUseProxies = immer.setUseProxies.bind(immer);
    /**
     * Apply an array of Immer patches to the first argument.
     *
     * This function is a producer, which means copy-on-write is in effect.
     */

    var applyPatches$1 = immer.applyPatches.bind(immer);
    /**
     * Create an Immer draft from the given base state, which may be a draft itself.
     * The draft can be modified until you finalize it with the `finishDraft` function.
     */

    var createDraft = immer.createDraft.bind(immer);
    /**
     * Finalize an Immer draft from a `createDraft` call, returning the base state
     * (if no changes were made) or a modified copy. The draft must *not* be
     * mutated afterwards.
     *
     * Pass a function as the 2nd argument to generate Immer patches based on the
     * changes that were made.
     */

    var finishDraft = immer.finishDraft.bind(immer);
    //# sourceMappingURL=immer.module.js.map

    function generateID() {
    	return Math.random().toString(36).substr(2, 9);
    }

    class Expression {
        constructor(items, path) {
            this[DRAFTABLE] = true;
            this.items = items;
            this.path = path;
            this.hint = false;
            this.error = false;
            this.id = generateID();
        }

        stringify() {
            return "(" + this.items.map(item => item.stringify()).join(" ") + ")";
        }
    }

    class Token {
        constructor(constant, variable, path, ...indices) {
            this[DRAFTABLE] = true;
            this.constant = constant;
            this.variable = variable;
            this.path = path;
            this.indices = indices;
            this.hint = false;
            this.error = false;
            this.id = generateID();
        }

        stringify() {
            return this.constant + (this.variable ? this.variable : '');
        }

        value() {
            return (!(this.variable && this.constant === 1) ? this.constant : '') + (this.variable || '')
        }
    }

    class Operator {
        constructor(operation) {
            this[DRAFTABLE] = true;
            this.symbol = {PLUS: '+', MINUS: '-', TIMES: '×', DIVIDE: '÷'}[operation];
            this.operation = operation;
            this.hint = false;
            this.error = false;
            this.id = generateID();
        }
        equals(other) {
            if (typeof other === 'string' || other instanceof String) {
                return this.operation === other;
            }
            return other instanceof Operator && other.operation === this.operation
        }
        stringify() {
            return this.symbol;
        }
    }


    function getPaths(path) {
    	let splitPath = path.replace(/,/g, ",items,").split(",");
    	let parentPath = splitPath.slice(0, splitPath.length - 2);
    	return [splitPath, parentPath];
    }

    class Equation {
        constructor(left, right) {
            this[DRAFTABLE] = true;
            this.left = left;
            this.right = right;
            this.id = generateID();
        }
        
        stringify() {
            return this.left.stringify() + " = " +  this.right.stringify();
        }

        updateToken(token, path, constant, variable) {
            return produce(this, draft => {
                let [tokenPath, parentPath] = getPaths(path);
                let parent = Object.path(draft, parentPath);
                let dest = parent.items.find(o => o.id == token.id);
                dest.constant = constant;
                dest.variable = variable;
            });
        }
    }

    function createHistory() {
        const initial = {past: [], current: null, index: -1, future: [], all: []};
        const { update, set, subscribe } = writable(initial);
        const step = (history, steps) => produce(history, draft => {
            if (steps > 0) {
                let arr = draft.future.slice(0, steps);
                draft.future = steps > draft.future.length ? [] : draft.future.slice(steps, draft.future.length);
                draft.past = draft.past.concat(arr);
            } else {
                let i = Math.max(draft.past.length + steps, 1);
                let arr = draft.past.slice(i, draft.past.length);
                draft.past = draft.past.slice(0, i);
                draft.future = arr.concat(draft.future);
            }
            draft.index = draft.past.length - 1;
            draft.current = draft.past[draft.index];
            draft.all = draft.past.concat(draft.future);
        });
        return {
            subscribe,
            push: state => update(history => produce(history, draft => {
                draft.current = state;
                draft.past.push(draft.current);
                draft.index = draft.past.length - 1;
                draft.future = [];
                draft.all = draft.past.concat(draft.future);
            })),
            step: steps => update(history => step(history, steps)),
            goTo: index => update(history => step(history, index - history.index)),
            reset: () => set(initial),
        }
    }

    const history = createHistory();

    // const initial = new Equation(
    //     new Expression([new Token(1, null), 'DIVIDE', new Token(2, 'x')]),
    //     new Expression([new Token(3, null)])
    // )
    const builder = new CTATTutoringServiceMessageBuilder ();
    const parse = new CTATAlgebraParser();
    window.parse = parse;
    let exp = parse.algParse("3x + 6 = 9");
    // let exp = parse.algParse("3x / ? = 11 - 32 + 6");
    // let exp = parse.algParse("2/3 * 5/4 = 9");
    // let exp = parse.algParse("x+-2=6x + 5/?/3");
    const initial = exp;

    // history.push(initial);


    Object.path = (o, p) => p.reduce((xs, x) => (xs && xs[x]) ? xs[x] : null, o);

    let dragOperation = {
        side: null,
        from: null,
        to: null
    };

    function createDraftEquation() {
    	const { subscribe, set, update } = writable(initial);
        const apply = (student=true) => update(eqn => {
            if (student) {
                var sai = new CTATSAI(dragOperation.side, dragOperation.from + "To" + dragOperation.to, parse.algStringify(eqn));
                if (CTATCommShell.commShell)
                    CTATCommShell.commShell.processComponentAction(sai);
            }
            
            if (get(history).current !== eqn) {
                history.push(eqn);
            }
            return eqn;
        });
        const moveItem = (srcData, destData, eqn) => {
            eqn = get(history).current;
            dragOperation.side = destData.item.path[0];

            if (srcData.item !== destData.item) {
                if (srcData.item instanceof Token) {
                    dragOperation.from = "Token";
                    if (destData.item instanceof Token) {
                        dragOperation.to = "Token";
                        let srcParent = Object.path(eqn, srcData.item.path.slice(0, -2));
                        let destParent = Object.path(eqn, destData.item.path.slice(0, -2));
                        
                        if (!destData.item.variable && !destData.item.constant) {
                            let src = parse.algParse(srcData.item.value());
                            let dest = Object.path(eqn, destData.item.path);
                            src.sign = dest.sign;
                            src.exp = dest.exp;
                            let next = parse.algReplaceExpression(eqn, dest, src);
                            return next;
                        } else if (srcParent === destParent) {
                            let parent = srcParent;
                            let indices = srcData.item.indices.concat(destData.item.indices);
                            let next = parse.algReplaceExpression(eqn, parent, parse.algApplyRulesSelectively(parent, ['combineSimilar'], false, ...indices));
                            parent = Object.path(next, srcData.item.path.slice(0, -2));
                            next = parse.algReplaceExpression(next, parent, parse.algApplyRules(parent, ['removeIdentity']));                        
                            return next;
                        }
                    } else if (destData.item instanceof Expression) {
                        dragOperation.to = "Expression";
                        let srcParent = Object.path(eqn, srcData.item.path.slice(0, -2));
                        let destParent = Object.path(eqn, destData.item.path.slice(0, -2));
                        if (srcParent === destParent && srcParent.operator !== 'EQUAL') {
                            let parent = Object.path(eqn, srcData.item.path.slice(0, -2));
                            let n0 = parseInt(srcData.item.path.slice(-1)[0]);
                            let n1 = parseInt(destData.item.path.slice(-1)[0]);

                            let next = parse.algReplaceExpression(eqn, parent, parse.algApplyRulesSelectively(parent, ['distribute', 'removeIdentity'], false, n0, n1));
                            return next;
                        }
                    }
                } else if (srcData.item instanceof Operator) {
                    dragOperation.from = "Operator";
                    if (destData.item instanceof Token || destData.item instanceof Expression) {
                        dragOperation.to = destData.item instanceof Token ? "Token" : "Expression";
                        let operation = srcData.item.operation;
                        eqn = parse.algParse(parse.algStringify(eqn)); // TODO Weird error unless we do this; 
                        // the grammar returns null on algReplaceExpression() if the token is dragged over the 9, then the ? in 3x + 6 = 9 /?, but not if the 9 is avoided
                        let dest = Object.path(eqn, destData.item.path);
                        let next = parse.algReplaceExpression(eqn, dest, parse.algCreateExpression(operation, dest, '?'));
                        return next;
                    }
                }
            }
            return eqn;
        };
    	return {
            subscribe,
            moveItem: (srcData, destData) => update(eqn => moveItem(srcData, destData, eqn)),
            resolveOperator: path => {
                let changed;
                update(eqn => {
                    let splitPath = path.split(',');
                    let clippedPath = splitPath.slice(0, -1);
                    let op0 = parseInt(splitPath.slice(-1)[0]) + 1;
                    let op1 = op0 - 2;
                    let parsed = parseGrammar(eqn);
                    let item0 = Object.path(parsed, clippedPath.concat(['items', op0]));
                    let item1 = Object.path(parsed, clippedPath.concat(['items', op1]));
                    let next = moveItem({ item: item0 }, { item: item1 });
                    changed = get(history).current !== next;
                    return next;
                });
                apply();
                return changed;
            },
            updateToken: (token, value) => {
                update(eqn => {
                    eqn = parse.algParse(get(history).current);
                    let e = parse.algParse(eqn);
                    let newToken = parse.algParse(value);
                    let oldToken = Object.path(e, token.path);
                    // parse.algFindExpression(e, oldToken);
                    newToken.sign = oldToken.sign;
                    newToken.exp = oldToken.exp;
                    dragOperation.side = token.path[0];
                    dragOperation.from = "Update";
                    dragOperation.to = "Token";
        
                    let next = parse.algReplaceExpression(e, oldToken, newToken);
                    return next;
                });
                apply();
            },
            set: next => set(next),
            reset: () => set(get(history).current),
            apply
    	};
    }
    const draftEquation = createDraftEquation();



    function createDragData() {
    	const { subscribe, set } = writable({});

    	return {
            subscribe,
            reset: () => set({}),
            set: (item, path) => {
                return set({item: item, path: path})
            },
    	};
    }
    const dragData = createDragData();

    function createDropData() {
    	const { subscribe, set, update } = writable({});

    	return {
            subscribe,
            reset: () => set({}),
            set: (item, path, drag) => {
                draftEquation.moveItem(drag, {item: item, path: path});
                return set({item: item, path: path})
            },
    	};
    }
    const dropData = createDropData();

    function parseGrammar(exp) {
        
        let test = parseGrammarTree(exp, []);
        
        return test
    }


    function parseGrammarTree(exp, ignoreSign) {
        let path = exp.path.join(',').split(',');
        switch(exp.operator) {
            case 'EQUAL':
                let operands = parse.algGetOperands(exp);
                return new Equation(parseGrammarTree(operands[0]), parseGrammarTree(operands[1]));
            case 'CONST':
                return new Token((ignoreSign ? 1 : exp.sign) * exp.value, null, path, parseInt(path.slice(-1)[0]));
            case 'VAR':
                return new Token(1, exp.variable, path, parseInt(path.slice(-1)[0]));
            case 'UMINUS':
                return new Token(-exp.base.value, null, path, parseInt(path.slice(-1)[0]));
            case 'UNKNOWN':
                return new Token(null, null, path, parseInt(path.slice(-1)[0]));
            case 'PLUS':
                return new Expression(exp.terms.reduce((res, item, i) => {
                    let token = parseGrammarTree(item, i > 0);
                    let operator = item.sign > 0 ? new Operator('PLUS') : new Operator('MINUS');
                    return i > 0 ? res.concat(operator, token) : res.concat(token);
                }, []), path);
            case 'TIMES':
                let divide = [];
                let newExp = new Expression(exp.factors.reduce((res, item, i) => {
                    let token = parseGrammarTree(item);
                    if (item.exp < 0) {
                        divide.push(token);
                        return res;
                    } else {
                        return i > 0 ? res.concat(new Operator('TIMES'), token) : res.concat(token);
                    }
                }, []), path);
                if (divide.length > 0) {
                    newExp = new Expression([
                        flatten(combineConstVars(newExp, path)),
                        new Operator('DIVIDE'),
                        flatten(combineConstVars(new Expression(divide.reduce((res, item, i) => {
                            return i > 0 ? res.concat(new Operator('TIMES'), item) : res.concat(item);
                        }, []))))
                    ]);
                }
                
                return flatten(combineConstVars(newExp, path));
            default:
                
                return null;
        }
    }

    function flatten(expression) {
        return expression.items.length === 1 ? expression.items[0] : expression;
    }

    function combineConstVars(expression, path) {
        let items = expression.items.reduce((res, item, i) => {
            if (item instanceof Operator) {
                return res.concat(item);
            } else if (i > 1) {
                let prev = res[res.length - 2];
                let op = res[res.length - 1];
                
                if(item instanceof Token && prev instanceof Token && item.variable && !prev.variable && op.equals('TIMES')) {
                    res.splice(res.length - 2, 2, new Token(
                        item.constant * prev.constant,
                        item.variable || '' + prev.variable || '',
                        item.path, parseInt(item.path.slice(-1)[0]), parseInt(prev.path.slice(-1)[0])));
                    return res;
                } else if (op.equals('DIVIDE')) { //TODO figure out a ref for this
                    res.splice(res.length - 2, 2, new Expression([prev, op, item], path));
                    return res;
                } else {
                    return res.concat(item);
                }
            } else {
                return res.concat(item);
            }
        }, []);
        expression.items = items;
        return expression;
    }

    function is_date(obj) {
        return Object.prototype.toString.call(obj) === '[object Date]';
    }

    function tick_spring(ctx, last_value, current_value, target_value) {
        if (typeof current_value === 'number' || is_date(current_value)) {
            // @ts-ignore
            const delta = target_value - current_value;
            // @ts-ignore
            const velocity = (current_value - last_value) / (ctx.dt || 1 / 60); // guard div by 0
            const spring = ctx.opts.stiffness * delta;
            const damper = ctx.opts.damping * velocity;
            const acceleration = (spring - damper) * ctx.inv_mass;
            const d = (velocity + acceleration) * ctx.dt;
            if (Math.abs(d) < ctx.opts.precision && Math.abs(delta) < ctx.opts.precision) {
                return target_value; // settled
            }
            else {
                ctx.settled = false; // signal loop to keep ticking
                // @ts-ignore
                return is_date(current_value) ?
                    new Date(current_value.getTime() + d) : current_value + d;
            }
        }
        else if (Array.isArray(current_value)) {
            // @ts-ignore
            return current_value.map((_, i) => tick_spring(ctx, last_value[i], current_value[i], target_value[i]));
        }
        else if (typeof current_value === 'object') {
            const next_value = {};
            for (const k in current_value)
                // @ts-ignore
                next_value[k] = tick_spring(ctx, last_value[k], current_value[k], target_value[k]);
            // @ts-ignore
            return next_value;
        }
        else {
            throw new Error(`Cannot spring ${typeof current_value} values`);
        }
    }
    function spring(value, opts = {}) {
        const store = writable(value);
        const { stiffness = 0.15, damping = 0.8, precision = 0.01 } = opts;
        let last_time;
        let task;
        let current_token;
        let last_value = value;
        let target_value = value;
        let inv_mass = 1;
        let inv_mass_recovery_rate = 0;
        let cancel_task = false;
        /* eslint-disable @typescript-eslint/no-use-before-define */
        function set(new_value, opts = {}) {
            target_value = new_value;
            const token = current_token = {};
            if (opts.hard || (spring.stiffness >= 1 && spring.damping >= 1)) {
                cancel_task = true; // cancel any running animation
                last_time = now();
                last_value = value;
                store.set(value = target_value);
                return new Promise(f => f()); // fulfil immediately
            }
            else if (opts.soft) {
                const rate = opts.soft === true ? .5 : +opts.soft;
                inv_mass_recovery_rate = 1 / (rate * 60);
                inv_mass = 0; // infinite mass, unaffected by spring forces
            }
            if (!task) {
                last_time = now();
                cancel_task = false;
                task = loop(now$$1 => {
                    if (cancel_task) {
                        cancel_task = false;
                        task = null;
                        return false;
                    }
                    inv_mass = Math.min(inv_mass + inv_mass_recovery_rate, 1);
                    const ctx = {
                        inv_mass,
                        opts: spring,
                        settled: true,
                        dt: (now$$1 - last_time) * 60 / 1000
                    };
                    const next_value = tick_spring(ctx, last_value, value, target_value);
                    last_time = now$$1;
                    last_value = value;
                    store.set(value = next_value);
                    if (ctx.settled)
                        task = null;
                    return !ctx.settled;
                });
            }
            return new Promise(fulfil => {
                task.promise.then(() => {
                    if (token === current_token)
                        fulfil();
                });
            });
        }
        /* eslint-enable @typescript-eslint/no-use-before-define */
        const spring = {
            set,
            update: (fn, opts) => set(fn(target_value, value), opts),
            subscribe: store.subscribe,
            stiffness,
            damping,
            precision
        };
        return spring;
    }

    function draggable(node, params) {
    	let x;
    	let y;

    	let {type: type, accepts: accepts} = params;
    	

    	let offset;
    	let entered = null;
    	let touchIndex = 0;

    	function handleMousedown(event) {
            event.stopPropagation();
    		if (event.button !== 0)
    			return;
    		x = event.clientX;
    		y = event.clientY;
            offset = {x: x, y: y};
            

    		node.dispatchEvent(new CustomEvent('dragstart', {
    			detail: { x: event.clientX - offset.x, y: event.clientY - offset.y }
    		}));

    		window.addEventListener('mousemove', handleMousemove);
    		window.addEventListener('mouseup', handleMouseup);
    		window.drag[touchIndex] = {node: node, type: type};
    		window.drop[touchIndex] = null;
    	}

    	

    	function handleMousemove(event) {
    		x = event.clientX;
    		y = event.clientY;

    		node.dispatchEvent(new CustomEvent('dragmove', {
    			detail: { x: event.clientX - offset.x, y: event.clientY - offset.y }
    		}));
    	}

    	

    	function handleMouseup(event) {
            event.stopPropagation();
    		x = event.clientX;
            y = event.clientY;
    		let dropped = window.drop[touchIndex] && window.drop[touchIndex].node !== node;
    		if (dropped) {
    			node.dispatchEvent(new CustomEvent('dropsend', {
    				detail: { x: event.clientX - offset.x, y: event.clientY - offset.y },
    				bubbles: true
    			}));
    			window.drop[touchIndex].node.dispatchEvent(new CustomEvent('dropreceive', {
    				detail: { x: event.clientX - offset.x, y: event.clientY - offset.y, drag: window.drag[touchIndex], drop: window.drop[touchIndex] },
    				bubbles: true
    			}));
    		} else {
    			node.dispatchEvent(new CustomEvent('dragend', {
    				detail: { x: event.clientX - offset.x, y: event.clientY - offset.y }
    			}));
    		}
    		window.drag[touchIndex] = null;
    		window.drop[touchIndex] = null;

    		window.removeEventListener('mousemove', handleMousemove);
    		window.removeEventListener('mouseup', handleMouseup);
    	}

    	function handleMouseEnter(event) {
    		x = event.clientX;
    		y = event.clientY;

    		let index = event.detail && event.detail.index ? event.detail.index : 0;
    		
    		if (window.drag[index] && window.drag[index].node !== node) {
    			// console.log("drag enter");
    			window.drop[index] = {node: node, type: type};
    			node.dispatchEvent(new CustomEvent('dragenter', {
    				detail: { x, y },
    				bubbles: true
    			}));
    		} else {
    			// console.log("mouse enter");
    			node.dispatchEvent(new CustomEvent('dragmouseenter', {
    				detail: { x, y },
    				bubbles: true
    			}));
    		}
    	}

    	function handleMouseExit(event) {
            event.stopPropagation();
    		x = event.clientX;
    		y = event.clientY;

    		let index = event.detail && event.detail.index ? event.detail.index : 0;

    		if (window.drag[index]) {
    			// console.log("drag exit");
    			node.dispatchEvent(new CustomEvent('dragexit', {
    				detail: { x, y }
    			}));
    			window.drop[index] = null;
    		} else {
    			// console.log("mouse exit");
    			node.dispatchEvent(new CustomEvent('dragmouseexit', {
    				detail: { x, y }
    			}));
    		}
    	}

    	function handleDrop(event) {
    		if (window.drag[touchIndex] && window.drop[touchIndex]) {
    			node.dispatchEvent(new CustomEvent('droprecieve', {
    				detail: { x, y, drag: window.drag[touchIndex], drop: window.drop[touchIndex] }
    			}));
    		}
    	}

    	function handleTouchDown(event) {
            event.stopPropagation();
    		if (!(event instanceof TouchEvent))
    			return;
    		touchIndex = event.changedTouches[0].identifier;
    		let curEvent = Object.values(event.touches).find(t => t.identifier === touchIndex);
    		x = curEvent.clientX;
    		y = curEvent.clientY;
            offset = {x: x, y: y};
            

    		node.dispatchEvent(new CustomEvent('dragstart', {
    			detail: { x: x - offset.x, y: y - offset.y }
    		}));

    		window.addEventListener('touchmove', handleTouchMove, {passive: true});
    		window.drag[touchIndex] = {node: node, type: type};
    		window.drop[touchIndex] = null;
    	}

    	function handleTouchMove(event) {
    		let curEvent = Object.values(event.touches).find(t => t.identifier === touchIndex);
    		x = curEvent.clientX;
    		y = curEvent.clientY;

    		node.dispatchEvent(new CustomEvent('dragmove', {
    			detail: { x: x - offset.x, y: y - offset.y }
    		}));

    		var element = document.elementFromPoint(x, y);
    		if (!element)
    			return;
    		if (element !== entered) {
    			if (entered) {
    				entered.dispatchEvent(new CustomEvent('mouseleave', {
    					detail: {index: touchIndex},
    					bubbles: true
    				}));
    				entered.dispatchEvent(new CustomEvent('mouseout', {
    					detail: {index: touchIndex},
    					bubbles: true
    				}));
    			}
    			entered = element;
    			entered.dispatchEvent(new CustomEvent('mouseenter', {
    				detail: {index: touchIndex},
    				bubbles: true
    			}));
    			entered.dispatchEvent(new CustomEvent('mouseover', {
    				detail: {index: touchIndex},
    				bubbles: true
    			}));
    		}
    	}

    	function handleTouchEnd(event) {
    		let dropped = window.drop[touchIndex] && window.drop[touchIndex].node !== node;

    		if (dropped) {
    			node.dispatchEvent(new CustomEvent('dropsend', {
    				detail: { x: x - offset.x, y: y - offset.y }
    			}));
    		} else {
    			node.dispatchEvent(new CustomEvent('dragend', {
    				detail: { x: x - offset.x, y: y - offset.y }
    			}));
    		}
    		if (entered) {
    			if (window.drag[touchIndex] && window.drop[touchIndex]) {
    				entered.dispatchEvent(new CustomEvent('dropreceive', {
    					detail: { x, y, drag: node, drop: window.drop[touchIndex].node },
    					bubbles: true
    				}));
    				entered.dispatchEvent(new CustomEvent('mouseleave', {
    					detail: {index: touchIndex},
    					bubbles: true
    				}));
    				entered.dispatchEvent(new CustomEvent('mouseout', {
    					detail: {index: touchIndex},
    					bubbles: true
    				}));
    			}
    		}
    		window.drag[touchIndex] = null;
    		window.drop[touchIndex] = null;

    		window.removeEventListener('touchmove', handleTouchMove);
    	}

    	function stopPropagation(event) {
            event.stopPropagation();
    	}

    	node.addEventListener('touchstart', handleTouchDown, {passive: true});
    	node.addEventListener('touchend', handleTouchEnd, {passive: true});

    	node.addEventListener('mousedown', handleMousedown);
    	node.addEventListener('mouseenter', handleMouseEnter);
    	node.addEventListener('mouseleave', handleMouseExit);

        node.addEventListener('mouseover', stopPropagation);
    	node.addEventListener('mouseout', stopPropagation);

    	return {
    		destroy() {
    			node.removeEventListener('touchstart', handleTouchDown);
    		
    			node.removeEventListener('mousedown', handleMousedown);
    			node.removeEventListener('mouseup', handleDrop);
    			node.removeEventListener('mouseenter', handleMouseEnter);
    			node.removeEventListener('mouseleave', handleMouseExit);
    			node.removeEventListener('touchend', handleTouchEnd);
    		}
    	};
    }

    /* src/components/Flaggable.svelte generated by Svelte v3.5.1 */

    const file = "src/components/Flaggable.svelte";

    function create_fragment(ctx) {
    	var div1, div0, div0_style_value, t, div1_style_value, current;

    	const default_slot_1 = ctx.$$slots.default;
    	const default_slot = create_slot(default_slot_1, ctx, null);

    	return {
    		c: function create() {
    			div1 = element("div");
    			div0 = element("div");
    			t = space();

    			if (default_slot) default_slot.c();
    			div0.className = "highlight svelte-1r0flp4";
    			div0.style.cssText = div0_style_value = `
            border-radius: ${ctx.hint || ctx.error ? ctx.size : 60}%;
            width: ${ctx.hint || ctx.error ? ctx.size : 60}%;
            height: ${ctx.hint || ctx.error ? ctx.size : 60}%;
        `;
    			add_location(div0, file, 11, 4, 221);

    			div1.className = "Flaggable svelte-1r0flp4";
    			div1.style.cssText = div1_style_value = ctx.divide ? "width: 100%" : "";
    			toggle_class(div1, "error", ctx.error);
    			toggle_class(div1, "hint", ctx.hint);
    			add_location(div1, file, 7, 0, 107);
    		},

    		l: function claim(nodes) {
    			if (default_slot) default_slot.l(div1_nodes);
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert(target, div1, anchor);
    			append(div1, div0);
    			append(div1, t);

    			if (default_slot) {
    				default_slot.m(div1, null);
    			}

    			current = true;
    		},

    		p: function update(changed, ctx) {
    			if ((!current || changed.hint || changed.error || changed.size) && div0_style_value !== (div0_style_value = `
            border-radius: ${ctx.hint || ctx.error ? ctx.size : 60}%;
            width: ${ctx.hint || ctx.error ? ctx.size : 60}%;
            height: ${ctx.hint || ctx.error ? ctx.size : 60}%;
        `)) {
    				div0.style.cssText = div0_style_value;
    			}

    			if (default_slot && default_slot.p && changed.$$scope) {
    				default_slot.p(get_slot_changes(default_slot_1, ctx, changed, null), get_slot_context(default_slot_1, ctx, null));
    			}

    			if ((!current || changed.divide) && div1_style_value !== (div1_style_value = ctx.divide ? "width: 100%" : "")) {
    				div1.style.cssText = div1_style_value;
    			}

    			if (changed.error) {
    				toggle_class(div1, "error", ctx.error);
    			}

    			if (changed.hint) {
    				toggle_class(div1, "hint", ctx.hint);
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			if (default_slot && default_slot.i) default_slot.i(local);
    			current = true;
    		},

    		o: function outro(local) {
    			if (default_slot && default_slot.o) default_slot.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div1);
    			}

    			if (default_slot) default_slot.d(detaching);
    		}
    	};
    }

    function instance($$self, $$props, $$invalidate) {
    	let { error, hint, size, divide } = $$props;

    	const writable_props = ['error', 'hint', 'size', 'divide'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<Flaggable> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;

    	$$self.$set = $$props => {
    		if ('error' in $$props) $$invalidate('error', error = $$props.error);
    		if ('hint' in $$props) $$invalidate('hint', hint = $$props.hint);
    		if ('size' in $$props) $$invalidate('size', size = $$props.size);
    		if ('divide' in $$props) $$invalidate('divide', divide = $$props.divide);
    		if ('$$scope' in $$props) $$invalidate('$$scope', $$scope = $$props.$$scope);
    	};

    	return {
    		error,
    		hint,
    		size,
    		divide,
    		$$slots,
    		$$scope
    	};
    }

    class Flaggable extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance, create_fragment, safe_not_equal, ["error", "hint", "size", "divide"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.error === undefined && !('error' in props)) {
    			console.warn("<Flaggable> was created without expected prop 'error'");
    		}
    		if (ctx.hint === undefined && !('hint' in props)) {
    			console.warn("<Flaggable> was created without expected prop 'hint'");
    		}
    		if (ctx.size === undefined && !('size' in props)) {
    			console.warn("<Flaggable> was created without expected prop 'size'");
    		}
    		if (ctx.divide === undefined && !('divide' in props)) {
    			console.warn("<Flaggable> was created without expected prop 'divide'");
    		}
    	}

    	get error() {
    		throw new Error("<Flaggable>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set error(value) {
    		throw new Error("<Flaggable>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get hint() {
    		throw new Error("<Flaggable>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set hint(value) {
    		throw new Error("<Flaggable>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get size() {
    		throw new Error("<Flaggable>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set size(value) {
    		throw new Error("<Flaggable>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get divide() {
    		throw new Error("<Flaggable>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set divide(value) {
    		throw new Error("<Flaggable>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/components/equation/Operator.svelte generated by Svelte v3.5.1 */

    const file$1 = "src/components/equation/Operator.svelte";

    // (37:0) <Flaggable error={error} hint={hint} size={110} divide={isDivide}>
    function create_default_slot(ctx) {
    	var div1, div0, t_value = ctx.isDivide ? '' : ctx.operator.symbol, t, dispose;

    	return {
    		c: function create() {
    			div1 = element("div");
    			div0 = element("div");
    			t = text(t_value);
    			div0.className = "content svelte-r8cd94";
    			add_location(div0, file$1, 38, 8, 1314);
    			div1.className = "Operator svelte-r8cd94";
    			toggle_class(div1, "divide", ctx.isDivide);
    			add_location(div1, file$1, 37, 4, 1227);
    			dispose = listen(div1, "dblclick", ctx.handleDoubleClick);
    		},

    		m: function mount(target, anchor) {
    			insert(target, div1, anchor);
    			append(div1, div0);
    			append(div0, t);
    		},

    		p: function update(changed, ctx) {
    			if ((changed.isDivide || changed.operator) && t_value !== (t_value = ctx.isDivide ? '' : ctx.operator.symbol)) {
    				set_data(t, t_value);
    			}

    			if (changed.isDivide) {
    				toggle_class(div1, "divide", ctx.isDivide);
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div1);
    			}

    			dispose();
    		}
    	};
    }

    function create_fragment$1(ctx) {
    	var current;

    	var flaggable = new Flaggable({
    		props: {
    		error: ctx.error,
    		hint: ctx.hint,
    		size: 110,
    		divide: ctx.isDivide,
    		$$slots: { default: [create_default_slot] },
    		$$scope: { ctx }
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			flaggable.$$.fragment.c();
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			mount_component(flaggable, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var flaggable_changes = {};
    			if (changed.error) flaggable_changes.error = ctx.error;
    			if (changed.hint) flaggable_changes.hint = ctx.hint;
    			if (changed.isDivide) flaggable_changes.divide = ctx.isDivide;
    			if (changed.$$scope || changed.isDivide || changed.operator) flaggable_changes.$$scope = { changed, ctx };
    			flaggable.$set(flaggable_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			flaggable.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			flaggable.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			flaggable.$destroy(detaching);
    		}
    	};
    }

    function instance$1($$self, $$props, $$invalidate) {
    	

        let { operator, path, error, hint } = $$props;  


        const audioFiles = {
            resolveError: {file: './audio/error.mp3', volume: 0.4},
            resolveSuccess: {file: './audio/click.wav', volume: 0.45},
        };
        var audioSource;
        onMount(() => {
    		audioSource = new Audio('./audio/click.wav');
        });
        
        function handleDoubleClick(event) {
            let success = draftEquation.resolveOperator(path);
            audioSource.src = success ? audioFiles.resolveSuccess.file : audioFiles.resolveError.file;        audioSource.volume = success ? audioFiles.resolveSuccess.volume : audioFiles.resolveError.volume;        audioSource.play();
            draftEquation.apply();
        }

    	const writable_props = ['operator', 'path', 'error', 'hint'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<Operator> was created with unknown prop '${key}'`);
    	});

    	$$self.$set = $$props => {
    		if ('operator' in $$props) $$invalidate('operator', operator = $$props.operator);
    		if ('path' in $$props) $$invalidate('path', path = $$props.path);
    		if ('error' in $$props) $$invalidate('error', error = $$props.error);
    		if ('hint' in $$props) $$invalidate('hint', hint = $$props.hint);
    	};

    	let isDivide;

    	$$self.$$.update = ($$dirty = { operator: 1, path: 1 }) => {
    		if ($$dirty.operator || $$dirty.path) { $$invalidate('isDivide', isDivide = operator.equals('DIVIDE') && path !== ''); }
    	};

    	return {
    		operator,
    		path,
    		error,
    		hint,
    		handleDoubleClick,
    		isDivide
    	};
    }

    class Operator$1 extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$1, create_fragment$1, safe_not_equal, ["operator", "path", "error", "hint"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.operator === undefined && !('operator' in props)) {
    			console.warn("<Operator> was created without expected prop 'operator'");
    		}
    		if (ctx.path === undefined && !('path' in props)) {
    			console.warn("<Operator> was created without expected prop 'path'");
    		}
    		if (ctx.error === undefined && !('error' in props)) {
    			console.warn("<Operator> was created without expected prop 'error'");
    		}
    		if (ctx.hint === undefined && !('hint' in props)) {
    			console.warn("<Operator> was created without expected prop 'hint'");
    		}
    	}

    	get operator() {
    		throw new Error("<Operator>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set operator(value) {
    		throw new Error("<Operator>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get path() {
    		throw new Error("<Operator>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set path(value) {
    		throw new Error("<Operator>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get error() {
    		throw new Error("<Operator>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set error(value) {
    		throw new Error("<Operator>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get hint() {
    		throw new Error("<Operator>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set hint(value) {
    		throw new Error("<Operator>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/components/equation/Token.svelte generated by Svelte v3.5.1 */

    const file$2 = "src/components/equation/Token.svelte";

    // (147:12) {:else}
    function create_else_block(ctx) {
    	var t_value = ctx.token.value(), t;

    	return {
    		c: function create() {
    			t = text(t_value);
    		},

    		m: function mount(target, anchor) {
    			insert(target, t, anchor);
    		},

    		p: function update(changed, ctx) {
    			if ((changed.token) && t_value !== (t_value = ctx.token.value())) {
    				set_data(t, t_value);
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(t);
    			}
    		}
    	};
    }

    // (145:12) {#if token.constant === null}
    function create_if_block_1(ctx) {
    	var input, dispose;

    	return {
    		c: function create() {
    			input = element("input");
    			attr(input, "type", "text");
    			input.size = 1;
    			input.value = ctx.value;
    			input.className = "svelte-1jh7yb0";
    			add_location(input, file$2, 145, 16, 4395);
    			dispose = listen(input, "change", ctx.updateToken);
    		},

    		m: function mount(target, anchor) {
    			insert(target, input, anchor);
    		},

    		p: function update(changed, ctx) {
    			if (changed.value) {
    				input.value = ctx.value;
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(input);
    			}

    			dispose();
    		}
    	};
    }

    // (155:16) {#if token.constant !== null}
    function create_if_block(ctx) {
    	var t_value = ctx.token.value(), t;

    	return {
    		c: function create() {
    			t = text(t_value);
    		},

    		m: function mount(target, anchor) {
    			insert(target, t, anchor);
    		},

    		p: function update(changed, ctx) {
    			if ((changed.token) && t_value !== (t_value = ctx.token.value())) {
    				set_data(t, t_value);
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(t);
    			}
    		}
    	};
    }

    // (126:0) <Flaggable error={error} hint={hint} size={150}>
    function create_default_slot$1(ctx) {
    	var div3, div0, t, div2, div1, draggable_action, dispose;

    	function select_block_type(ctx) {
    		if (ctx.token.constant === null) return create_if_block_1;
    		return create_else_block;
    	}

    	var current_block_type = select_block_type(ctx);
    	var if_block0 = current_block_type(ctx);

    	var if_block1 = (ctx.token.constant !== null) && create_if_block(ctx);

    	return {
    		c: function create() {
    			div3 = element("div");
    			div0 = element("div");
    			if_block0.c();
    			t = space();
    			div2 = element("div");
    			div1 = element("div");
    			if (if_block1) if_block1.c();
    			div0.className = "content svelte-1jh7yb0";
    			add_location(div0, file$2, 143, 8, 4315);
    			div1.className = "content svelte-1jh7yb0";
    			add_location(div1, file$2, 153, 12, 4688);
    			div2.className = "mover svelte-1jh7yb0";
    			set_style(div2, "transform", "translate(" + ctx.$coords.x + "px," + ctx.$coords.y + "px)");
    			toggle_class(div2, "fade", ctx.dropAnim);
    			add_location(div2, file$2, 150, 8, 4553);
    			div3.className = "Token svelte-1jh7yb0";
    			toggle_class(div3, "dragging", ctx.dragging);
    			toggle_class(div3, "hovering", ctx.hovering && !ctx.dropAnim);
    			toggle_class(div3, "dragover", ctx.dragover);
    			toggle_class(div3, "onTop", ctx.dragging || (Math.abs(ctx.$coords.x) + Math.abs(ctx.$coords.y) > 0.1));
    			toggle_class(div3, "editable", ctx.token.variable  === null && ctx.token.constant === null);
    			add_location(div3, file$2, 126, 4, 3537);

    			dispose = [
    				listen(div3, "dragstart", ctx.handleDragStart),
    				listen(div3, "dragmove", ctx.handleDragMove),
    				listen(div3, "dragend", ctx.handleDragEnd),
    				listen(div3, "dragmouseenter", ctx.handleMouseEnter),
    				listen(div3, "dragmouseexit", ctx.handleMouseExit),
    				listen(div3, "dragenter", ctx.handleDragEnter),
    				listen(div3, "dragexit", ctx.handleDragExit),
    				listen(div3, "dropsend", ctx.handleDropSend),
    				listen(div3, "dropreceive", ctx.handleDropReceive),
    				listen(div3, "mouseup", ctx.mouseup_handler)
    			];
    		},

    		m: function mount(target, anchor) {
    			insert(target, div3, anchor);
    			append(div3, div0);
    			if_block0.m(div0, null);
    			append(div3, t);
    			append(div3, div2);
    			append(div2, div1);
    			if (if_block1) if_block1.m(div1, null);
    			draggable_action = draggable.call(null, div3, {type: "token", accepts: ["operator", "token"]}) || {};
    		},

    		p: function update(changed, ctx) {
    			if (current_block_type === (current_block_type = select_block_type(ctx)) && if_block0) {
    				if_block0.p(changed, ctx);
    			} else {
    				if_block0.d(1);
    				if_block0 = current_block_type(ctx);
    				if (if_block0) {
    					if_block0.c();
    					if_block0.m(div0, null);
    				}
    			}

    			if (ctx.token.constant !== null) {
    				if (if_block1) {
    					if_block1.p(changed, ctx);
    				} else {
    					if_block1 = create_if_block(ctx);
    					if_block1.c();
    					if_block1.m(div1, null);
    				}
    			} else if (if_block1) {
    				if_block1.d(1);
    				if_block1 = null;
    			}

    			if (changed.$coords) {
    				set_style(div2, "transform", "translate(" + ctx.$coords.x + "px," + ctx.$coords.y + "px)");
    			}

    			if (changed.dropAnim) {
    				toggle_class(div2, "fade", ctx.dropAnim);
    			}

    			if (changed.dragging) {
    				toggle_class(div3, "dragging", ctx.dragging);
    			}

    			if ((changed.hovering || changed.dropAnim)) {
    				toggle_class(div3, "hovering", ctx.hovering && !ctx.dropAnim);
    			}

    			if (changed.dragover) {
    				toggle_class(div3, "dragover", ctx.dragover);
    			}

    			if ((changed.dragging || changed.$coords)) {
    				toggle_class(div3, "onTop", ctx.dragging || (Math.abs(ctx.$coords.x) + Math.abs(ctx.$coords.y) > 0.1));
    			}

    			if (changed.token) {
    				toggle_class(div3, "editable", ctx.token.variable  === null && ctx.token.constant === null);
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div3);
    			}

    			if_block0.d();
    			if (if_block1) if_block1.d();
    			if (draggable_action && typeof draggable_action.destroy === 'function') draggable_action.destroy();
    			run_all(dispose);
    		}
    	};
    }

    function create_fragment$2(ctx) {
    	var current;

    	var flaggable = new Flaggable({
    		props: {
    		error: ctx.error,
    		hint: ctx.hint,
    		size: 150,
    		$$slots: { default: [create_default_slot$1] },
    		$$scope: { ctx }
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			flaggable.$$.fragment.c();
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			mount_component(flaggable, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var flaggable_changes = {};
    			if (changed.error) flaggable_changes.error = ctx.error;
    			if (changed.hint) flaggable_changes.hint = ctx.hint;
    			if (changed.$$scope || changed.dragging || changed.hovering || changed.dropAnim || changed.dragover || changed.$coords || changed.token || changed.value) flaggable_changes.$$scope = { changed, ctx };
    			flaggable.$set(flaggable_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			flaggable.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			flaggable.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			flaggable.$destroy(detaching);
    		}
    	};
    }

    let fadeAnimTime = 300;

    function instance$2($$self, $$props, $$invalidate) {
    	let $history, $draftEquation, $dragData, $coords;

    	validate_store(history, 'history');
    	subscribe($$self, history, $$value => { $history = $$value; $$invalidate('$history', $history); });
    	validate_store(draftEquation, 'draftEquation');
    	subscribe($$self, draftEquation, $$value => { $draftEquation = $$value; $$invalidate('$draftEquation', $draftEquation); });
    	validate_store(dragData, 'dragData');
    	subscribe($$self, dragData, $$value => { $dragData = $$value; $$invalidate('$dragData', $dragData); });

    	

        let { error, hint, token, path } = $$props;

        const audioFiles = {
            dragStart: {file: './audio/pop.wav', volume: 0.45},
            dropRecieve: {file: './audio/click.wav', volume: 0.4},
            dropError: {file: './audio/error.mp3', volume: 0.4},
        };
        var audioSource;
        onMount(() => {
    		audioSource = new Audio('./audio/pop.wav');
    	});

        let dragging = false;
        let hovering = false;
        let dragover = false;
        let dropAnim = false;

    	const coords = spring({ x: 0, y: 0 }, {
    		stiffness: 0.05,
    		damping: 0.3
    	}); validate_store(coords, 'coords'); subscribe($$self, coords, $$value => { $coords = $$value; $$invalidate('$coords', $coords); });

    	function handleDragStart(e) {
            audioSource.src = audioFiles.dragStart.file;        audioSource.volume = audioFiles.dragStart.volume;        audioSource.play();
            if (token.constant !== null) {
                coords.stiffness = coords.damping = 1; $$invalidate('coords', coords);
                $$invalidate('dragging', dragging = true);
                dragData.set(token, path);
            } else {
                e.stopPropagation();
            }
    	}

    	function handleDragMove(event) {
    		coords.update($coords => ({
    			x: event.detail.x,
    			y: event.detail.y
    		}));
        }
        
        function handleDropSend(event) {
            if ($history.current === $draftEquation) {
                handleDragEnd(event);
                return;
            }
            $$invalidate('dropAnim', dropAnim = true);
            $$invalidate('hovering', hovering = false);
            setTimeout(() => {
                coords.set({ x: 0, y: 0 });
                $$invalidate('dropAnim', dropAnim = false);
                $$invalidate('dragging', dragging = false);
            }, fadeAnimTime);
        }

    	function handleDragEnd(event) {
    		coords.update($coords => ({
    			x: event.detail.x,
    			y: event.detail.y
    		}));
            coords.stiffness = 0.05; $$invalidate('coords', coords);
            coords.damping = 0.3; $$invalidate('coords', coords);
            coords.set({ x: 0, y: 0 });
            $$invalidate('dragging', dragging = false);
            $$invalidate('hovering', hovering = false);
            dropData.reset();
        }

        function handleMouseEnter(event) {
            $$invalidate('hovering', hovering = true);
        }

        function handleMouseExit(event) {
            $$invalidate('hovering', hovering = false);
            $$invalidate('dragover', dragover = false);
        }

        function handleDragEnter(event) {
            event.stopPropagation();
            $$invalidate('dragover', dragover = true);
            dropData.set(token, path, $dragData);
        }

        function handleDragExit(event) {
            event.stopPropagation();
            $$invalidate('dragover', dragover = false);
            $$invalidate('hovering', hovering = false);
        }

        function handleDropReceive(event) {
            event.stopPropagation();        
            let success = $history.current !== $draftEquation;
            audioSource.src = success ? audioFiles.dropRecieve.file : audioFiles.dropError.file;        audioSource.volume = success ? audioFiles.dropRecieve.volume : audioFiles.dropError.volume;        audioSource.play();
            draftEquation.apply();
        }

        function updateToken(e) {
            draftEquation.updateToken(token, e.target.value);
        }

    	const writable_props = ['error', 'hint', 'token', 'path'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<Token> was created with unknown prop '${key}'`);
    	});

    	function mouseup_handler() {dragover = false; $$invalidate('dragover', dragover);}

    	$$self.$set = $$props => {
    		if ('error' in $$props) $$invalidate('error', error = $$props.error);
    		if ('hint' in $$props) $$invalidate('hint', hint = $$props.hint);
    		if ('token' in $$props) $$invalidate('token', token = $$props.token);
    		if ('path' in $$props) $$invalidate('path', path = $$props.path);
    	};

    	let value;

    	$$self.$$.update = ($$dirty = { token: 1 }) => {
    		if ($$dirty.token) { $$invalidate('value', value = (token.constant !== null && !(token.variable !== null && token.constant === 1) ? token.constant: '') + (token.variable ? token.variable : '')); }
    	};

    	return {
    		error,
    		hint,
    		token,
    		path,
    		dragging,
    		hovering,
    		dragover,
    		dropAnim,
    		coords,
    		handleDragStart,
    		handleDragMove,
    		handleDropSend,
    		handleDragEnd,
    		handleMouseEnter,
    		handleMouseExit,
    		handleDragEnter,
    		handleDragExit,
    		handleDropReceive,
    		updateToken,
    		value,
    		$coords,
    		mouseup_handler
    	};
    }

    class Token$1 extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$2, create_fragment$2, safe_not_equal, ["error", "hint", "token", "path"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.error === undefined && !('error' in props)) {
    			console.warn("<Token> was created without expected prop 'error'");
    		}
    		if (ctx.hint === undefined && !('hint' in props)) {
    			console.warn("<Token> was created without expected prop 'hint'");
    		}
    		if (ctx.token === undefined && !('token' in props)) {
    			console.warn("<Token> was created without expected prop 'token'");
    		}
    		if (ctx.path === undefined && !('path' in props)) {
    			console.warn("<Token> was created without expected prop 'path'");
    		}
    	}

    	get error() {
    		throw new Error("<Token>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set error(value) {
    		throw new Error("<Token>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get hint() {
    		throw new Error("<Token>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set hint(value) {
    		throw new Error("<Token>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get token() {
    		throw new Error("<Token>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set token(value) {
    		throw new Error("<Token>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get path() {
    		throw new Error("<Token>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set path(value) {
    		throw new Error("<Token>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    function droppable(node, params) {
    	let hovered = 0;
    	let {type: type, accepts: accepts} = params;
        
    	function handleMouseEnter(event) {
            hovered++;
            event.stopPropagation();
            if (hovered > 1)
                return;
    		let x = event.clientX;
    		let y = event.clientY;

    		let index = event.detail && event.detail.index ? event.detail.index : 0;
    		
    		if (window.drag[index] && window.drag[index].node !== node) {
    			window.drop[index] = {node: node, type: type};
    			node.dispatchEvent(new CustomEvent('dragenter', {
    				detail: { x, y },
    				bubbles: true
    			}));
    		} else {
    			node.dispatchEvent(new CustomEvent('dragmouseenter', {
    				detail: { x, y },
    				bubbles: true
    			}));
    		}
    	}

    	function handleMouseExit(event) {
            hovered--;
            event.stopPropagation();
    		let x = event.clientX;
    		let y = event.clientY;

    		let index = event.detail && event.detail.index ? event.detail.index : 0;

    		if (window.drag[index]) {
    			node.dispatchEvent(new CustomEvent('dragexit', {
    				detail: { x, y },
    				bubbles: true
    			}));
    			window.drop[index] = null;
    		} else {
    			node.dispatchEvent(new CustomEvent('dragmouseexit', {
    				detail: { x, y },
    				bubbles: true
    			}));
    		}
    	}

    	node.addEventListener('mouseover', handleMouseEnter);
        node.addEventListener('mouseout', handleMouseExit);
        // node.addEventListener('mouseover', () => {
        //     hovered++;
        //     console.log(hovered, hovered > 0);
        //     event.stopPropagation();
        // });
    	// node.addEventListener('mouseout', () => {
        //     hovered--;
        //     console.log(hovered, hovered > 0);
        //     event.stopPropagation();
        // });

    	return {
    		destroy() {
    			node.removeEventListener('mouseover', handleMouseEnter);
    			node.removeEventListener('mouseout', handleMouseExit);
    		}
    	};
    }

    /* src/components/equation/Expression.svelte generated by Svelte v3.5.1 */

    const file$3 = "src/components/equation/Expression.svelte";

    function get_each_context(ctx, list, i) {
    	const child_ctx = Object.create(ctx);
    	child_ctx.item = list[i];
    	child_ctx.i = i;
    	return child_ctx;
    }

    // (79:44) 
    function create_if_block_2(ctx) {
    	var current;

    	var tokencomponent = new Token$1({
    		props: {
    		token: ctx.item,
    		path: ctx.path + "," + ctx.i,
    		hint: ctx.item.hint,
    		error: ctx.item.error
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			tokencomponent.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(tokencomponent, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var tokencomponent_changes = {};
    			if (changed.expression) tokencomponent_changes.token = ctx.item;
    			if (changed.path) tokencomponent_changes.path = ctx.path + "," + ctx.i;
    			if (changed.expression) tokencomponent_changes.hint = ctx.item.hint;
    			if (changed.expression) tokencomponent_changes.error = ctx.item.error;
    			tokencomponent.$set(tokencomponent_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			tokencomponent.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			tokencomponent.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			tokencomponent.$destroy(detaching);
    		}
    	};
    }

    // (77:49) 
    function create_if_block_1$1(ctx) {
    	var current;

    	var expression_1 = new Expression_1({
    		props: {
    		expression: ctx.item,
    		path: ctx.path + "," + ctx.i,
    		parentDivide: ctx.isDivide,
    		hint: ctx.item.hint,
    		error: ctx.item.error
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			expression_1.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(expression_1, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var expression_1_changes = {};
    			if (changed.expression) expression_1_changes.expression = ctx.item;
    			if (changed.path) expression_1_changes.path = ctx.path + "," + ctx.i;
    			if (changed.isDivide) expression_1_changes.parentDivide = ctx.isDivide;
    			if (changed.expression) expression_1_changes.hint = ctx.item.hint;
    			if (changed.expression) expression_1_changes.error = ctx.item.error;
    			expression_1.$set(expression_1_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			expression_1.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			expression_1.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			expression_1.$destroy(detaching);
    		}
    	};
    }

    // (75:12) {#if item instanceof Operator}
    function create_if_block$1(ctx) {
    	var current;

    	var operatorcomponent = new Operator$1({
    		props: {
    		operator: ctx.item,
    		path: ctx.path + "," + ctx.i,
    		hint: ctx.item.hint,
    		error: ctx.item.error
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			operatorcomponent.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(operatorcomponent, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var operatorcomponent_changes = {};
    			if (changed.expression) operatorcomponent_changes.operator = ctx.item;
    			if (changed.path) operatorcomponent_changes.path = ctx.path + "," + ctx.i;
    			if (changed.expression) operatorcomponent_changes.hint = ctx.item.hint;
    			if (changed.expression) operatorcomponent_changes.error = ctx.item.error;
    			operatorcomponent.$set(operatorcomponent_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			operatorcomponent.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			operatorcomponent.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			operatorcomponent.$destroy(detaching);
    		}
    	};
    }

    // (74:8) {#each expression.items as item, i}
    function create_each_block(ctx) {
    	var current_block_type_index, if_block, if_block_anchor, current;

    	var if_block_creators = [
    		create_if_block$1,
    		create_if_block_1$1,
    		create_if_block_2
    	];

    	var if_blocks = [];

    	function select_block_type(ctx) {
    		if (ctx.item instanceof Operator) return 0;
    		if (ctx.item instanceof Expression) return 1;
    		if (ctx.item instanceof Token) return 2;
    		return -1;
    	}

    	if (~(current_block_type_index = select_block_type(ctx))) {
    		if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
    	}

    	return {
    		c: function create() {
    			if (if_block) if_block.c();
    			if_block_anchor = empty();
    		},

    		m: function mount(target, anchor) {
    			if (~current_block_type_index) if_blocks[current_block_type_index].m(target, anchor);
    			insert(target, if_block_anchor, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var previous_block_index = current_block_type_index;
    			current_block_type_index = select_block_type(ctx);
    			if (current_block_type_index === previous_block_index) {
    				if (~current_block_type_index) if_blocks[current_block_type_index].p(changed, ctx);
    			} else {
    				if (if_block) {
    					group_outros();
    					on_outro(() => {
    						if_blocks[previous_block_index].d(1);
    						if_blocks[previous_block_index] = null;
    					});
    					if_block.o(1);
    					check_outros();
    				}

    				if (~current_block_type_index) {
    					if_block = if_blocks[current_block_type_index];
    					if (!if_block) {
    						if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
    						if_block.c();
    					}
    					if_block.i(1);
    					if_block.m(if_block_anchor.parentNode, if_block_anchor);
    				} else {
    					if_block = null;
    				}
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			if (if_block) if_block.i();
    			current = true;
    		},

    		o: function outro(local) {
    			if (if_block) if_block.o();
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (~current_block_type_index) if_blocks[current_block_type_index].d(detaching);

    			if (detaching) {
    				detach(if_block_anchor);
    			}
    		}
    	};
    }

    // (62:0) <Flaggable error={error} hint={hint} size={110}>
    function create_default_slot$2(ctx) {
    	var div, droppable_action, current, dispose;

    	var each_value = ctx.expression.items;

    	var each_blocks = [];

    	for (var i = 0; i < each_value.length; i += 1) {
    		each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
    	}

    	function outro_block(i, detaching, local) {
    		if (each_blocks[i]) {
    			if (detaching) {
    				on_outro(() => {
    					each_blocks[i].d(detaching);
    					each_blocks[i] = null;
    				});
    			}

    			each_blocks[i].o(local);
    		}
    	}

    	return {
    		c: function create() {
    			div = element("div");

    			for (var i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].c();
    			}
    			div.className = "Expression svelte-10ie4j0";
    			toggle_class(div, "divide", ctx.isDivide);
    			toggle_class(div, "parentheses", ctx.expression.items.length > 1 && !ctx.expression.items[1].equals('DIVIDE') && ctx.path.split(",").length > 1 && !ctx.parentDivide);
    			toggle_class(div, "hovering", ctx.hovering);
    			toggle_class(div, "dragover", ctx.dragover);
    			add_location(div, file$3, 62, 4, 1983);

    			dispose = [
    				listen(div, "dragmouseenter", ctx.handleMouseEnter),
    				listen(div, "dragmouseexit", ctx.handleMouseExit),
    				listen(div, "dragenter", ctx.handleDragEnter),
    				listen(div, "dragexit", ctx.handleDragExit),
    				listen(div, "dropreceive", ctx.handleDropReceive)
    			];
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);

    			for (var i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].m(div, null);
    			}

    			droppable_action = droppable.call(null, div, {type: "expression", accepts:["token", "operator"]}) || {};
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			if (changed.expression || changed.Operator || changed.path || changed.Expression || changed.isDivide || changed.Token) {
    				each_value = ctx.expression.items;

    				for (var i = 0; i < each_value.length; i += 1) {
    					const child_ctx = get_each_context(ctx, each_value, i);

    					if (each_blocks[i]) {
    						each_blocks[i].p(changed, child_ctx);
    						each_blocks[i].i(1);
    					} else {
    						each_blocks[i] = create_each_block(child_ctx);
    						each_blocks[i].c();
    						each_blocks[i].i(1);
    						each_blocks[i].m(div, null);
    					}
    				}

    				group_outros();
    				for (; i < each_blocks.length; i += 1) outro_block(i, 1, 1);
    				check_outros();
    			}

    			if (changed.isDivide) {
    				toggle_class(div, "divide", ctx.isDivide);
    			}

    			if ((changed.expression || changed.path || changed.parentDivide)) {
    				toggle_class(div, "parentheses", ctx.expression.items.length > 1 && !ctx.expression.items[1].equals('DIVIDE') && ctx.path.split(",").length > 1 && !ctx.parentDivide);
    			}

    			if (changed.hovering) {
    				toggle_class(div, "hovering", ctx.hovering);
    			}

    			if (changed.dragover) {
    				toggle_class(div, "dragover", ctx.dragover);
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			for (var i = 0; i < each_value.length; i += 1) each_blocks[i].i();

    			current = true;
    		},

    		o: function outro(local) {
    			each_blocks = each_blocks.filter(Boolean);
    			for (let i = 0; i < each_blocks.length; i += 1) outro_block(i, 0, 0);

    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}

    			destroy_each(each_blocks, detaching);

    			if (droppable_action && typeof droppable_action.destroy === 'function') droppable_action.destroy();
    			run_all(dispose);
    		}
    	};
    }

    function create_fragment$3(ctx) {
    	var current;

    	var flaggable = new Flaggable({
    		props: {
    		error: ctx.error,
    		hint: ctx.hint,
    		size: 110,
    		$$slots: { default: [create_default_slot$2] },
    		$$scope: { ctx }
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			flaggable.$$.fragment.c();
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			mount_component(flaggable, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var flaggable_changes = {};
    			if (changed.error) flaggable_changes.error = ctx.error;
    			if (changed.hint) flaggable_changes.hint = ctx.hint;
    			if (changed.$$scope || changed.isDivide || changed.expression || changed.path || changed.parentDivide || changed.hovering || changed.dragover) flaggable_changes.$$scope = { changed, ctx };
    			flaggable.$set(flaggable_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			flaggable.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			flaggable.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			flaggable.$destroy(detaching);
    		}
    	};
    }

    function instance$3($$self, $$props, $$invalidate) {
    	let $dragData, $history, $draftEquation;

    	validate_store(dragData, 'dragData');
    	subscribe($$self, dragData, $$value => { $dragData = $$value; $$invalidate('$dragData', $dragData); });
    	validate_store(history, 'history');
    	subscribe($$self, history, $$value => { $history = $$value; $$invalidate('$history', $history); });
    	validate_store(draftEquation, 'draftEquation');
    	subscribe($$self, draftEquation, $$value => { $draftEquation = $$value; $$invalidate('$draftEquation', $draftEquation); });

    	
        
        let { expression, path, parentDivide, error, hint } = $$props;

        const audioFiles = {
            dragStart: {file: './audio/pop.wav', volume: 0.45},
            dropRecieve: {file: './audio/click.wav', volume: 0.4},
            dropError: {file: './audio/error.mp3', volume: 0.4},
        };
        var audioSource;
        onMount(() => {
    		audioSource = new Audio('./audio/pop.wav');
        });

        let hovering = false;
        let dragover = false;

        function handleMouseEnter(event) {
            event.stopPropagation();
            $$invalidate('hovering', hovering = true);
        }
        function handleMouseExit(event) {
            event.stopPropagation();
            $$invalidate('hovering', hovering = false);
            $$invalidate('dragover', dragover = false);
        }
        function handleDragEnter(event) {
            event.stopPropagation();
            $$invalidate('dragover', dragover = true);
            dropData.set(expression, path, $dragData);
        }
        function handleDragExit(event) {
            $$invalidate('dragover', dragover = false);
            $$invalidate('hovering', hovering = false);
        }
        function handleDropReceive(event) {
            event.stopPropagation();
            let success = $history.current !== $draftEquation;
            audioSource.src = success ? audioFiles.dropRecieve.file : audioFiles.dropError.file;        audioSource.volume = success ? audioFiles.dropRecieve.volume : audioFiles.dropError.volume;        audioSource.play();
            draftEquation.apply();
        }

    	const writable_props = ['expression', 'path', 'parentDivide', 'error', 'hint'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<Expression> was created with unknown prop '${key}'`);
    	});

    	$$self.$set = $$props => {
    		if ('expression' in $$props) $$invalidate('expression', expression = $$props.expression);
    		if ('path' in $$props) $$invalidate('path', path = $$props.path);
    		if ('parentDivide' in $$props) $$invalidate('parentDivide', parentDivide = $$props.parentDivide);
    		if ('error' in $$props) $$invalidate('error', error = $$props.error);
    		if ('hint' in $$props) $$invalidate('hint', hint = $$props.hint);
    	};

    	let isDivide;

    	$$self.$$.update = ($$dirty = { expression: 1 }) => {
    		if ($$dirty.expression) { $$invalidate('isDivide', isDivide = expression.items.length > 1 && expression.items[1].equals('DIVIDE')); }
    	};

    	return {
    		expression,
    		path,
    		parentDivide,
    		error,
    		hint,
    		hovering,
    		dragover,
    		handleMouseEnter,
    		handleMouseExit,
    		handleDragEnter,
    		handleDragExit,
    		handleDropReceive,
    		isDivide
    	};
    }

    class Expression_1 extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$3, create_fragment$3, safe_not_equal, ["expression", "path", "parentDivide", "error", "hint"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.expression === undefined && !('expression' in props)) {
    			console.warn("<Expression> was created without expected prop 'expression'");
    		}
    		if (ctx.path === undefined && !('path' in props)) {
    			console.warn("<Expression> was created without expected prop 'path'");
    		}
    		if (ctx.parentDivide === undefined && !('parentDivide' in props)) {
    			console.warn("<Expression> was created without expected prop 'parentDivide'");
    		}
    		if (ctx.error === undefined && !('error' in props)) {
    			console.warn("<Expression> was created without expected prop 'error'");
    		}
    		if (ctx.hint === undefined && !('hint' in props)) {
    			console.warn("<Expression> was created without expected prop 'hint'");
    		}
    	}

    	get expression() {
    		throw new Error("<Expression>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set expression(value) {
    		throw new Error("<Expression>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get path() {
    		throw new Error("<Expression>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set path(value) {
    		throw new Error("<Expression>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get parentDivide() {
    		throw new Error("<Expression>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set parentDivide(value) {
    		throw new Error("<Expression>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get error() {
    		throw new Error("<Expression>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set error(value) {
    		throw new Error("<Expression>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get hint() {
    		throw new Error("<Expression>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set hint(value) {
    		throw new Error("<Expression>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/components/equation/Equation.svelte generated by Svelte v3.5.1 */

    const file$4 = "src/components/equation/Equation.svelte";

    // (18:46) 
    function create_if_block_5(ctx) {
    	var div, current;

    	var tokencomponent = new Token$1({
    		props: {
    		token: ctx.state.left,
    		path: "left",
    		hint: ctx.state.left.hint,
    		error: ctx.error === 'left'
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			div = element("div");
    			tokencomponent.$$.fragment.c();
    			div.className = "padding svelte-mi3zu1";
    			add_location(div, file$4, 18, 12, 799);
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);
    			mount_component(tokencomponent, div, null);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var tokencomponent_changes = {};
    			if (changed.state) tokencomponent_changes.token = ctx.state.left;
    			if (changed.state) tokencomponent_changes.hint = ctx.state.left.hint;
    			if (changed.error) tokencomponent_changes.error = ctx.error === 'left';
    			tokencomponent.$set(tokencomponent_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			tokencomponent.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			tokencomponent.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}

    			tokencomponent.$destroy();
    		}
    	};
    }

    // (16:51) 
    function create_if_block_4(ctx) {
    	var current;

    	var expressioncomponent = new Expression_1({
    		props: {
    		expression: ctx.state.left,
    		path: "left",
    		parentDivide: false,
    		hint: ctx.state.left.hint,
    		error: ctx.error === 'left'
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			expressioncomponent.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(expressioncomponent, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var expressioncomponent_changes = {};
    			if (changed.state) expressioncomponent_changes.expression = ctx.state.left;
    			if (changed.state) expressioncomponent_changes.hint = ctx.state.left.hint;
    			if (changed.error) expressioncomponent_changes.error = ctx.error === 'left';
    			expressioncomponent.$set(expressioncomponent_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			expressioncomponent.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			expressioncomponent.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			expressioncomponent.$destroy(detaching);
    		}
    	};
    }

    // (14:8) {#if state.left instanceof Operator}
    function create_if_block_3(ctx) {
    	var current;

    	var operatorcomponent = new Operator$1({
    		props: {
    		operator: ctx.state.left,
    		path: "left",
    		hint: ctx.state.left.hint,
    		error: ctx.error === 'left'
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			operatorcomponent.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(operatorcomponent, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var operatorcomponent_changes = {};
    			if (changed.state) operatorcomponent_changes.operator = ctx.state.left;
    			if (changed.state) operatorcomponent_changes.hint = ctx.state.left.hint;
    			if (changed.error) operatorcomponent_changes.error = ctx.error === 'left';
    			operatorcomponent.$set(operatorcomponent_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			operatorcomponent.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			operatorcomponent.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			operatorcomponent.$destroy(detaching);
    		}
    	};
    }

    // (28:47) 
    function create_if_block_2$1(ctx) {
    	var div, current;

    	var tokencomponent = new Token$1({
    		props: {
    		token: ctx.state.right,
    		path: "right",
    		hint: ctx.state.right.hint,
    		error: ctx.error === 'right'
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			div = element("div");
    			tokencomponent.$$.fragment.c();
    			div.className = "padding svelte-mi3zu1";
    			add_location(div, file$4, 28, 12, 1435);
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);
    			mount_component(tokencomponent, div, null);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var tokencomponent_changes = {};
    			if (changed.state) tokencomponent_changes.token = ctx.state.right;
    			if (changed.state) tokencomponent_changes.hint = ctx.state.right.hint;
    			if (changed.error) tokencomponent_changes.error = ctx.error === 'right';
    			tokencomponent.$set(tokencomponent_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			tokencomponent.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			tokencomponent.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}

    			tokencomponent.$destroy();
    		}
    	};
    }

    // (26:52) 
    function create_if_block_1$2(ctx) {
    	var current;

    	var expressioncomponent = new Expression_1({
    		props: {
    		expression: ctx.state.right,
    		path: "right",
    		parentDivide: false,
    		hint: ctx.state.right.hint,
    		error: ctx.error === 'right'
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			expressioncomponent.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(expressioncomponent, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var expressioncomponent_changes = {};
    			if (changed.state) expressioncomponent_changes.expression = ctx.state.right;
    			if (changed.state) expressioncomponent_changes.hint = ctx.state.right.hint;
    			if (changed.error) expressioncomponent_changes.error = ctx.error === 'right';
    			expressioncomponent.$set(expressioncomponent_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			expressioncomponent.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			expressioncomponent.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			expressioncomponent.$destroy(detaching);
    		}
    	};
    }

    // (24:8) {#if state.right instanceof Operator}
    function create_if_block$2(ctx) {
    	var current;

    	var operatorcomponent = new Operator$1({
    		props: {
    		operator: ctx.state.right,
    		path: "right",
    		hint: ctx.state.right.hint,
    		error: ctx.error === 'right'
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			operatorcomponent.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(operatorcomponent, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var operatorcomponent_changes = {};
    			if (changed.state) operatorcomponent_changes.operator = ctx.state.right;
    			if (changed.state) operatorcomponent_changes.hint = ctx.state.right.hint;
    			if (changed.error) operatorcomponent_changes.error = ctx.error === 'right';
    			operatorcomponent.$set(operatorcomponent_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			operatorcomponent.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			operatorcomponent.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			operatorcomponent.$destroy(detaching);
    		}
    	};
    }

    function create_fragment$4(ctx) {
    	var div3, div0, current_block_type_index, if_block0, t0, div1, t2, div2, current_block_type_index_1, if_block1, current;

    	var if_block_creators = [
    		create_if_block_3,
    		create_if_block_4,
    		create_if_block_5
    	];

    	var if_blocks = [];

    	function select_block_type(ctx) {
    		if (ctx.state.left instanceof Operator) return 0;
    		if (ctx.state.left instanceof Expression) return 1;
    		if (ctx.state.left instanceof Token) return 2;
    		return -1;
    	}

    	if (~(current_block_type_index = select_block_type(ctx))) {
    		if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
    	}

    	var if_block_creators_1 = [
    		create_if_block$2,
    		create_if_block_1$2,
    		create_if_block_2$1
    	];

    	var if_blocks_1 = [];

    	function select_block_type_1(ctx) {
    		if (ctx.state.right instanceof Operator) return 0;
    		if (ctx.state.right instanceof Expression) return 1;
    		if (ctx.state.right instanceof Token) return 2;
    		return -1;
    	}

    	if (~(current_block_type_index_1 = select_block_type_1(ctx))) {
    		if_block1 = if_blocks_1[current_block_type_index_1] = if_block_creators_1[current_block_type_index_1](ctx);
    	}

    	return {
    		c: function create() {
    			div3 = element("div");
    			div0 = element("div");
    			if (if_block0) if_block0.c();
    			t0 = space();
    			div1 = element("div");
    			div1.textContent = "=";
    			t2 = space();
    			div2 = element("div");
    			if (if_block1) if_block1.c();
    			div0.className = "left";
    			add_location(div0, file$4, 12, 4, 363);
    			div1.className = "equals svelte-mi3zu1";
    			add_location(div1, file$4, 21, 4, 955);
    			div2.className = "right";
    			add_location(div2, file$4, 22, 4, 987);
    			div3.className = "equation svelte-mi3zu1";
    			add_location(div3, file$4, 11, 0, 336);
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert(target, div3, anchor);
    			append(div3, div0);
    			if (~current_block_type_index) if_blocks[current_block_type_index].m(div0, null);
    			append(div3, t0);
    			append(div3, div1);
    			append(div3, t2);
    			append(div3, div2);
    			if (~current_block_type_index_1) if_blocks_1[current_block_type_index_1].m(div2, null);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var previous_block_index = current_block_type_index;
    			current_block_type_index = select_block_type(ctx);
    			if (current_block_type_index === previous_block_index) {
    				if (~current_block_type_index) if_blocks[current_block_type_index].p(changed, ctx);
    			} else {
    				if (if_block0) {
    					group_outros();
    					on_outro(() => {
    						if_blocks[previous_block_index].d(1);
    						if_blocks[previous_block_index] = null;
    					});
    					if_block0.o(1);
    					check_outros();
    				}

    				if (~current_block_type_index) {
    					if_block0 = if_blocks[current_block_type_index];
    					if (!if_block0) {
    						if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
    						if_block0.c();
    					}
    					if_block0.i(1);
    					if_block0.m(div0, null);
    				} else {
    					if_block0 = null;
    				}
    			}

    			var previous_block_index_1 = current_block_type_index_1;
    			current_block_type_index_1 = select_block_type_1(ctx);
    			if (current_block_type_index_1 === previous_block_index_1) {
    				if (~current_block_type_index_1) if_blocks_1[current_block_type_index_1].p(changed, ctx);
    			} else {
    				if (if_block1) {
    					group_outros();
    					on_outro(() => {
    						if_blocks_1[previous_block_index_1].d(1);
    						if_blocks_1[previous_block_index_1] = null;
    					});
    					if_block1.o(1);
    					check_outros();
    				}

    				if (~current_block_type_index_1) {
    					if_block1 = if_blocks_1[current_block_type_index_1];
    					if (!if_block1) {
    						if_block1 = if_blocks_1[current_block_type_index_1] = if_block_creators_1[current_block_type_index_1](ctx);
    						if_block1.c();
    					}
    					if_block1.i(1);
    					if_block1.m(div2, null);
    				} else {
    					if_block1 = null;
    				}
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			if (if_block0) if_block0.i();
    			if (if_block1) if_block1.i();
    			current = true;
    		},

    		o: function outro(local) {
    			if (if_block0) if_block0.o();
    			if (if_block1) if_block1.o();
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div3);
    			}

    			if (~current_block_type_index) if_blocks[current_block_type_index].d();
    			if (~current_block_type_index_1) if_blocks_1[current_block_type_index_1].d();
    		}
    	};
    }

    function instance$4($$self, $$props, $$invalidate) {
    	

        let { state, error } = $$props;

    	const writable_props = ['state', 'error'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<Equation> was created with unknown prop '${key}'`);
    	});

    	$$self.$set = $$props => {
    		if ('state' in $$props) $$invalidate('state', state = $$props.state);
    		if ('error' in $$props) $$invalidate('error', error = $$props.error);
    	};

    	return { state, error };
    }

    class Equation$1 extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$4, create_fragment$4, safe_not_equal, ["state", "error"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.state === undefined && !('state' in props)) {
    			console.warn("<Equation> was created without expected prop 'state'");
    		}
    		if (ctx.error === undefined && !('error' in props)) {
    			console.warn("<Equation> was created without expected prop 'error'");
    		}
    	}

    	get state() {
    		throw new Error("<Equation>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set state(value) {
    		throw new Error("<Equation>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get error() {
    		throw new Error("<Equation>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set error(value) {
    		throw new Error("<Equation>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/components/equation/PreviewEquation.svelte generated by Svelte v3.5.1 */

    const file$5 = "src/components/equation/PreviewEquation.svelte";

    // (28:4) {#if showDraft }
    function create_if_block$3(ctx) {
    	var div, current;

    	var equation = new Equation$1({
    		props: { state: ctx.draft },
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			div = element("div");
    			equation.$$.fragment.c();
    			div.className = "preview svelte-b65mk0";
    			add_location(div, file$5, 28, 8, 626);
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);
    			mount_component(equation, div, null);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var equation_changes = {};
    			if (changed.draft) equation_changes.state = ctx.draft;
    			equation.$set(equation_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			equation.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			equation.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}

    			equation.$destroy();
    		}
    	};
    }

    function create_fragment$5(ctx) {
    	var div, t, current, dispose;

    	var equation = new Equation$1({
    		props: { state: ctx.state, error: ctx.error },
    		$$inline: true
    	});

    	var if_block = (ctx.showDraft) && create_if_block$3(ctx);

    	return {
    		c: function create() {
    			div = element("div");
    			equation.$$.fragment.c();
    			t = space();
    			if (if_block) if_block.c();
    			div.className = "root svelte-b65mk0";
    			add_location(div, file$5, 22, 0, 436);

    			dispose = [
    				listen(div, "mousemove", ctx.handleMove),
    				listen(div, "mouseleave", ctx.handleMouseLeave),
    				listen(div, "mouseup", ctx.handleMouseUp)
    			];
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);
    			mount_component(equation, div, null);
    			append(div, t);
    			if (if_block) if_block.m(div, null);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var equation_changes = {};
    			if (changed.state) equation_changes.state = ctx.state;
    			if (changed.error) equation_changes.error = ctx.error;
    			equation.$set(equation_changes);

    			if (ctx.showDraft) {
    				if (if_block) {
    					if_block.p(changed, ctx);
    					if_block.i(1);
    				} else {
    					if_block = create_if_block$3(ctx);
    					if_block.c();
    					if_block.i(1);
    					if_block.m(div, null);
    				}
    			} else if (if_block) {
    				group_outros();
    				on_outro(() => {
    					if_block.d(1);
    					if_block = null;
    				});

    				if_block.o(1);
    				check_outros();
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			equation.$$.fragment.i(local);

    			if (if_block) if_block.i();
    			current = true;
    		},

    		o: function outro(local) {
    			equation.$$.fragment.o(local);
    			if (if_block) if_block.o();
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}

    			equation.$destroy();

    			if (if_block) if_block.d();
    			run_all(dispose);
    		}
    	};
    }

    function instance$5($$self, $$props, $$invalidate) {
    	let { state, draft, error } = $$props;
        
        let showDraft;

        function handleMove(e) {
            if (Object.keys(window.drag).some(key => window.drag[key])) {
                $$invalidate('showDraft', showDraft = true);
            }
        }
        function handleMouseLeave(e) {
            $$invalidate('showDraft', showDraft = false);
        }
        function handleMouseUp(e) {
            $$invalidate('showDraft', showDraft = false);
        }

    	const writable_props = ['state', 'draft', 'error'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<PreviewEquation> was created with unknown prop '${key}'`);
    	});

    	$$self.$set = $$props => {
    		if ('state' in $$props) $$invalidate('state', state = $$props.state);
    		if ('draft' in $$props) $$invalidate('draft', draft = $$props.draft);
    		if ('error' in $$props) $$invalidate('error', error = $$props.error);
    	};

    	return {
    		state,
    		draft,
    		error,
    		showDraft,
    		handleMove,
    		handleMouseLeave,
    		handleMouseUp
    	};
    }

    class PreviewEquation extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$5, create_fragment$5, safe_not_equal, ["state", "draft", "error"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.state === undefined && !('state' in props)) {
    			console.warn("<PreviewEquation> was created without expected prop 'state'");
    		}
    		if (ctx.draft === undefined && !('draft' in props)) {
    			console.warn("<PreviewEquation> was created without expected prop 'draft'");
    		}
    		if (ctx.error === undefined && !('error' in props)) {
    			console.warn("<PreviewEquation> was created without expected prop 'error'");
    		}
    	}

    	get state() {
    		throw new Error("<PreviewEquation>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set state(value) {
    		throw new Error("<PreviewEquation>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get draft() {
    		throw new Error("<PreviewEquation>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set draft(value) {
    		throw new Error("<PreviewEquation>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get error() {
    		throw new Error("<PreviewEquation>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set error(value) {
    		throw new Error("<PreviewEquation>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/components/equation/DraggableOperator.svelte generated by Svelte v3.5.1 */

    const file$6 = "src/components/equation/DraggableOperator.svelte";

    // (97:0) <Flaggable error={error} hint={hint} size={110} divide={isDivide}>
    function create_default_slot$3(ctx) {
    	var div3, div0, t0_value = ctx.isDivide ? '' : ctx.operator.symbol, t0, t1, div2, div1, t2_value = ctx.isDivide ? '' : ctx.operator.symbol, t2, draggable_action, dispose;

    	return {
    		c: function create() {
    			div3 = element("div");
    			div0 = element("div");
    			t0 = text(t0_value);
    			t1 = space();
    			div2 = element("div");
    			div1 = element("div");
    			t2 = text(t2_value);
    			div0.className = "content svelte-vczxg5";
    			add_location(div0, file$6, 112, 8, 3113);
    			div1.className = "content svelte-vczxg5";
    			add_location(div1, file$6, 117, 12, 3330);
    			div2.className = "mover svelte-vczxg5";
    			set_style(div2, "transform", "translate(" + ctx.$coords.x + "px," + ctx.$coords.y + "px)");
    			toggle_class(div2, "fade", ctx.dropAnim);
    			add_location(div2, file$6, 113, 8, 3182);
    			div3.className = "Operator svelte-vczxg5";
    			toggle_class(div3, "divide", ctx.isDivide);
    			toggle_class(div3, "dragging", ctx.dragging);
    			toggle_class(div3, "hovering", ctx.hovering && !ctx.dropAnim);
    			toggle_class(div3, "onTop", ctx.dragging || (Math.abs(ctx.$coords.x) + Math.abs(ctx.$coords.y) > 0.1));
    			add_location(div3, file$6, 97, 4, 2470);

    			dispose = [
    				listen(div3, "dragstart", ctx.handleDragStart),
    				listen(div3, "dragmove", ctx.handleDragMove),
    				listen(div3, "dragend", ctx.handleDragEnd),
    				listen(div3, "dragmouseenter", ctx.handleMouseEnter),
    				listen(div3, "dragmouseexit", ctx.handleMouseExit),
    				listen(div3, "dragenter", ctx.handleDragEnter),
    				listen(div3, "dragexit", ctx.handleDragExit),
    				listen(div3, "dropsend", ctx.handleDropSend),
    				listen(div3, "mouseup", ctx.mouseup_handler)
    			];
    		},

    		m: function mount(target, anchor) {
    			insert(target, div3, anchor);
    			append(div3, div0);
    			append(div0, t0);
    			append(div3, t1);
    			append(div3, div2);
    			append(div2, div1);
    			append(div1, t2);
    			draggable_action = draggable.call(null, div3, {type: "operator", accepts: []}) || {};
    		},

    		p: function update(changed, ctx) {
    			if ((changed.isDivide || changed.operator) && t0_value !== (t0_value = ctx.isDivide ? '' : ctx.operator.symbol)) {
    				set_data(t0, t0_value);
    			}

    			if ((changed.isDivide || changed.operator) && t2_value !== (t2_value = ctx.isDivide ? '' : ctx.operator.symbol)) {
    				set_data(t2, t2_value);
    			}

    			if (changed.$coords) {
    				set_style(div2, "transform", "translate(" + ctx.$coords.x + "px," + ctx.$coords.y + "px)");
    			}

    			if (changed.dropAnim) {
    				toggle_class(div2, "fade", ctx.dropAnim);
    			}

    			if (changed.isDivide) {
    				toggle_class(div3, "divide", ctx.isDivide);
    			}

    			if (changed.dragging) {
    				toggle_class(div3, "dragging", ctx.dragging);
    			}

    			if ((changed.hovering || changed.dropAnim)) {
    				toggle_class(div3, "hovering", ctx.hovering && !ctx.dropAnim);
    			}

    			if ((changed.dragging || changed.$coords)) {
    				toggle_class(div3, "onTop", ctx.dragging || (Math.abs(ctx.$coords.x) + Math.abs(ctx.$coords.y) > 0.1));
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div3);
    			}

    			if (draggable_action && typeof draggable_action.destroy === 'function') draggable_action.destroy();
    			run_all(dispose);
    		}
    	};
    }

    function create_fragment$6(ctx) {
    	var current;

    	var flaggable = new Flaggable({
    		props: {
    		error: ctx.error,
    		hint: ctx.hint,
    		size: 110,
    		divide: ctx.isDivide,
    		$$slots: { default: [create_default_slot$3] },
    		$$scope: { ctx }
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			flaggable.$$.fragment.c();
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			mount_component(flaggable, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var flaggable_changes = {};
    			if (changed.error) flaggable_changes.error = ctx.error;
    			if (changed.hint) flaggable_changes.hint = ctx.hint;
    			if (changed.isDivide) flaggable_changes.divide = ctx.isDivide;
    			if (changed.$$scope || changed.isDivide || changed.dragging || changed.hovering || changed.dropAnim || changed.$coords || changed.operator) flaggable_changes.$$scope = { changed, ctx };
    			flaggable.$set(flaggable_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			flaggable.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			flaggable.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			flaggable.$destroy(detaching);
    		}
    	};
    }

    let fadeAnimTime$1 = 300;

    function instance$6($$self, $$props, $$invalidate) {
    	let $coords;

    	

        let { operator, path, error, hint } = $$props;  


        const audioFiles = {
            dragStart: {file: './audio/pop.wav', volume: 0.45},
            dropRecieve: {file: './audio/click.wav', volume: 0.4},
        };
        var audioSource;
        onMount(() => {
    		audioSource = new Audio('./audio/pop.wav');
    	});

        let dragging = false;
        let hovering = false;
        let dragover = false;
        let dropAnim = false;

    	const coords = spring({ x: 0, y: 0 }, {
    		stiffness: 0.05,
    		damping: 0.3
    	}); validate_store(coords, 'coords'); subscribe($$self, coords, $$value => { $coords = $$value; $$invalidate('$coords', $coords); });

    	function handleDragStart() {
    		coords.stiffness = coords.damping = 1; $$invalidate('coords', coords);
            $$invalidate('dragging', dragging = true);
            audioSource.src = audioFiles.dragStart.file;        audioSource.volume = audioFiles.dragStart.volume;        audioSource.play();
            dragData.set(operator, path);
    	}

    	function handleDragMove(event) {
    		coords.update($coords => ({
    			x: event.detail.x,
    			y: event.detail.y
    		}));
        }
        
        function handleDropSend(event) {
            $$invalidate('dropAnim', dropAnim = true);
            $$invalidate('hovering', hovering = false);
            setTimeout(() => {
                coords.set({ x: 0, y: 0 });
                $$invalidate('dropAnim', dropAnim = false);
                $$invalidate('dragging', dragging = false);
            }, fadeAnimTime$1);
        }

    	function handleDragEnd(event) {
    		coords.update($coords => ({
    			x: event.detail.x,
    			y: event.detail.y
    		}));
            coords.stiffness = 0.05; $$invalidate('coords', coords);
            coords.damping = 0.3; $$invalidate('coords', coords);
            coords.set({ x: 0, y: 0 });
            $$invalidate('dragging', dragging = false);
            $$invalidate('hovering', hovering = false);
            draftEquation.reset();
            dropData.reset();
        }
        function handleMouseEnter(event) {
            $$invalidate('hovering', hovering = true);
        }
        function handleMouseExit(event) {
            $$invalidate('hovering', hovering = false);
            $$invalidate('dragover', dragover = false);
        }
        function handleDragEnter(event) {
            $$invalidate('dragover', dragover = true);
        }
        function handleDragExit(event) {
            $$invalidate('dragover', dragover = false);
            $$invalidate('hovering', hovering = false);
        }

    	const writable_props = ['operator', 'path', 'error', 'hint'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<DraggableOperator> was created with unknown prop '${key}'`);
    	});

    	function mouseup_handler() {dragover = false; $$invalidate('dragover', dragover);}

    	$$self.$set = $$props => {
    		if ('operator' in $$props) $$invalidate('operator', operator = $$props.operator);
    		if ('path' in $$props) $$invalidate('path', path = $$props.path);
    		if ('error' in $$props) $$invalidate('error', error = $$props.error);
    		if ('hint' in $$props) $$invalidate('hint', hint = $$props.hint);
    	};

    	let isDivide;

    	$$self.$$.update = ($$dirty = { operator: 1, path: 1 }) => {
    		if ($$dirty.operator || $$dirty.path) { $$invalidate('isDivide', isDivide = operator.equals('DIVIDE') && path !== ''); }
    	};

    	return {
    		operator,
    		path,
    		error,
    		hint,
    		dragging,
    		hovering,
    		dragover,
    		dropAnim,
    		coords,
    		handleDragStart,
    		handleDragMove,
    		handleDropSend,
    		handleDragEnd,
    		handleMouseEnter,
    		handleMouseExit,
    		handleDragEnter,
    		handleDragExit,
    		isDivide,
    		$coords,
    		mouseup_handler
    	};
    }

    class DraggableOperator extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$6, create_fragment$6, safe_not_equal, ["operator", "path", "error", "hint"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.operator === undefined && !('operator' in props)) {
    			console.warn("<DraggableOperator> was created without expected prop 'operator'");
    		}
    		if (ctx.path === undefined && !('path' in props)) {
    			console.warn("<DraggableOperator> was created without expected prop 'path'");
    		}
    		if (ctx.error === undefined && !('error' in props)) {
    			console.warn("<DraggableOperator> was created without expected prop 'error'");
    		}
    		if (ctx.hint === undefined && !('hint' in props)) {
    			console.warn("<DraggableOperator> was created without expected prop 'hint'");
    		}
    	}

    	get operator() {
    		throw new Error("<DraggableOperator>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set operator(value) {
    		throw new Error("<DraggableOperator>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get path() {
    		throw new Error("<DraggableOperator>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set path(value) {
    		throw new Error("<DraggableOperator>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get error() {
    		throw new Error("<DraggableOperator>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set error(value) {
    		throw new Error("<DraggableOperator>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get hint() {
    		throw new Error("<DraggableOperator>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set hint(value) {
    		throw new Error("<DraggableOperator>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/components/OperatorBox.svelte generated by Svelte v3.5.1 */

    const file$7 = "src/components/OperatorBox.svelte";

    function get_each_context$1(ctx, list, i) {
    	const child_ctx = Object.create(ctx);
    	child_ctx.operator = list[i];
    	child_ctx.i = i;
    	return child_ctx;
    }

    // (9:8) {#each operators as operator, i}
    function create_each_block$1(ctx) {
    	var current;

    	var draggableoperator = new DraggableOperator({
    		props: {
    		operator: ctx.operator,
    		path: '',
    		hint: ctx.operator.hint,
    		error: ctx.operator.error
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			draggableoperator.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(draggableoperator, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var draggableoperator_changes = {};
    			if (changed.operators) draggableoperator_changes.operator = ctx.operator;
    			if (changed.operators) draggableoperator_changes.hint = ctx.operator.hint;
    			if (changed.operators) draggableoperator_changes.error = ctx.operator.error;
    			draggableoperator.$set(draggableoperator_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			draggableoperator.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			draggableoperator.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			draggableoperator.$destroy(detaching);
    		}
    	};
    }

    function create_fragment$7(ctx) {
    	var div1, h2, t_1, div0, current;

    	var each_value = ctx.operators;

    	var each_blocks = [];

    	for (var i = 0; i < each_value.length; i += 1) {
    		each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
    	}

    	function outro_block(i, detaching, local) {
    		if (each_blocks[i]) {
    			if (detaching) {
    				on_outro(() => {
    					each_blocks[i].d(detaching);
    					each_blocks[i] = null;
    				});
    			}

    			each_blocks[i].o(local);
    		}
    	}

    	return {
    		c: function create() {
    			div1 = element("div");
    			h2 = element("h2");
    			h2.textContent = "Operators";
    			t_1 = space();
    			div0 = element("div");

    			for (var i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].c();
    			}
    			h2.className = "svelte-1ggmhwr";
    			add_location(h2, file$7, 6, 4, 150);
    			div0.className = "operator-container svelte-1ggmhwr";
    			add_location(div0, file$7, 7, 4, 173);
    			div1.className = "operator-box svelte-1ggmhwr";
    			add_location(div1, file$7, 5, 0, 119);
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert(target, div1, anchor);
    			append(div1, h2);
    			append(div1, t_1);
    			append(div1, div0);

    			for (var i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].m(div0, null);
    			}

    			current = true;
    		},

    		p: function update(changed, ctx) {
    			if (changed.operators) {
    				each_value = ctx.operators;

    				for (var i = 0; i < each_value.length; i += 1) {
    					const child_ctx = get_each_context$1(ctx, each_value, i);

    					if (each_blocks[i]) {
    						each_blocks[i].p(changed, child_ctx);
    						each_blocks[i].i(1);
    					} else {
    						each_blocks[i] = create_each_block$1(child_ctx);
    						each_blocks[i].c();
    						each_blocks[i].i(1);
    						each_blocks[i].m(div0, null);
    					}
    				}

    				group_outros();
    				for (; i < each_blocks.length; i += 1) outro_block(i, 1, 1);
    				check_outros();
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			for (var i = 0; i < each_value.length; i += 1) each_blocks[i].i();

    			current = true;
    		},

    		o: function outro(local) {
    			each_blocks = each_blocks.filter(Boolean);
    			for (let i = 0; i < each_blocks.length; i += 1) outro_block(i, 0, 0);

    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div1);
    			}

    			destroy_each(each_blocks, detaching);
    		}
    	};
    }

    function instance$7($$self, $$props, $$invalidate) {
    	let { operators } = $$props;

    	const writable_props = ['operators'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<OperatorBox> was created with unknown prop '${key}'`);
    	});

    	$$self.$set = $$props => {
    		if ('operators' in $$props) $$invalidate('operators', operators = $$props.operators);
    	};

    	return { operators };
    }

    class OperatorBox extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$7, create_fragment$7, safe_not_equal, ["operators"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.operators === undefined && !('operators' in props)) {
    			console.warn("<OperatorBox> was created without expected prop 'operators'");
    		}
    	}

    	get operators() {
    		throw new Error("<OperatorBox>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set operators(value) {
    		throw new Error("<OperatorBox>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/components/equation/display/TokenDisplay.svelte generated by Svelte v3.5.1 */

    const file$8 = "src/components/equation/display/TokenDisplay.svelte";

    function create_fragment$8(ctx) {
    	var div, span, t_value = ctx.token.constant == null ? "□" : ctx.token.value(), t;

    	return {
    		c: function create() {
    			div = element("div");
    			span = element("span");
    			t = text(t_value);
    			span.className = "content";
    			add_location(span, file$8, 1, 4, 31);
    			div.className = "TokenDisplay svelte-bh7w8q";
    			add_location(div, file$8, 0, 0, 0);
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);
    			append(div, span);
    			append(span, t);
    		},

    		p: function update(changed, ctx) {
    			if ((changed.token) && t_value !== (t_value = ctx.token.constant == null ? "□" : ctx.token.value())) {
    				set_data(t, t_value);
    			}
    		},

    		i: noop,
    		o: noop,

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}
    		}
    	};
    }

    function instance$8($$self, $$props, $$invalidate) {
    	let { token, path } = $$props;

    	const writable_props = ['token', 'path'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<TokenDisplay> was created with unknown prop '${key}'`);
    	});

    	$$self.$set = $$props => {
    		if ('token' in $$props) $$invalidate('token', token = $$props.token);
    		if ('path' in $$props) $$invalidate('path', path = $$props.path);
    	};

    	return { token, path };
    }

    class TokenDisplay extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$8, create_fragment$8, safe_not_equal, ["token", "path"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.token === undefined && !('token' in props)) {
    			console.warn("<TokenDisplay> was created without expected prop 'token'");
    		}
    		if (ctx.path === undefined && !('path' in props)) {
    			console.warn("<TokenDisplay> was created without expected prop 'path'");
    		}
    	}

    	get token() {
    		throw new Error("<TokenDisplay>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set token(value) {
    		throw new Error("<TokenDisplay>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get path() {
    		throw new Error("<TokenDisplay>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set path(value) {
    		throw new Error("<TokenDisplay>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/components/equation/display/OperatorDisplay.svelte generated by Svelte v3.5.1 */

    const file$9 = "src/components/equation/display/OperatorDisplay.svelte";

    function create_fragment$9(ctx) {
    	var div, t_value = ctx.operator.symbol, t;

    	return {
    		c: function create() {
    			div = element("div");
    			t = text(t_value);
    			div.className = "" + "OperatorDisplay" + " svelte-19a9hcy";
    			toggle_class(div, "divide", ctx.operator.equals('DIVIDE'));
    			add_location(div, file$9, 5, 0, 60);
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);
    			append(div, t);
    		},

    		p: function update(changed, ctx) {
    			if ((changed.operator) && t_value !== (t_value = ctx.operator.symbol)) {
    				set_data(t, t_value);
    			}

    			if (changed.operator) {
    				toggle_class(div, "divide", ctx.operator.equals('DIVIDE'));
    			}
    		},

    		i: noop,
    		o: noop,

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}
    		}
    	};
    }

    function instance$9($$self, $$props, $$invalidate) {
    	let { operator, path } = $$props;

    	const writable_props = ['operator', 'path'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<OperatorDisplay> was created with unknown prop '${key}'`);
    	});

    	$$self.$set = $$props => {
    		if ('operator' in $$props) $$invalidate('operator', operator = $$props.operator);
    		if ('path' in $$props) $$invalidate('path', path = $$props.path);
    	};

    	return { operator, path };
    }

    class OperatorDisplay extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$9, create_fragment$9, safe_not_equal, ["operator", "path"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.operator === undefined && !('operator' in props)) {
    			console.warn("<OperatorDisplay> was created without expected prop 'operator'");
    		}
    		if (ctx.path === undefined && !('path' in props)) {
    			console.warn("<OperatorDisplay> was created without expected prop 'path'");
    		}
    	}

    	get operator() {
    		throw new Error("<OperatorDisplay>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set operator(value) {
    		throw new Error("<OperatorDisplay>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get path() {
    		throw new Error("<OperatorDisplay>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set path(value) {
    		throw new Error("<OperatorDisplay>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/components/equation/display/ExpressionDisplay.svelte generated by Svelte v3.5.1 */

    const file$a = "src/components/equation/display/ExpressionDisplay.svelte";

    function get_each_context$2(ctx, list, i) {
    	const child_ctx = Object.create(ctx);
    	child_ctx.item = list[i];
    	child_ctx.i = i;
    	return child_ctx;
    }

    // (22:40) 
    function create_if_block_2$2(ctx) {
    	var current;

    	var tokendisplay = new TokenDisplay({
    		props: { token: ctx.item, path: ctx.path + "," + ctx.i },
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			tokendisplay.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(tokendisplay, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var tokendisplay_changes = {};
    			if (changed.expression) tokendisplay_changes.token = ctx.item;
    			if (changed.path) tokendisplay_changes.path = ctx.path + "," + ctx.i;
    			tokendisplay.$set(tokendisplay_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			tokendisplay.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			tokendisplay.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			tokendisplay.$destroy(detaching);
    		}
    	};
    }

    // (20:45) 
    function create_if_block_1$3(ctx) {
    	var current;

    	var expressiondisplay = new ExpressionDisplay({
    		props: {
    		expression: ctx.item,
    		parentDivide: ctx.isDivide,
    		path: ctx.path + "," + ctx.i
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			expressiondisplay.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(expressiondisplay, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var expressiondisplay_changes = {};
    			if (changed.expression) expressiondisplay_changes.expression = ctx.item;
    			if (changed.isDivide) expressiondisplay_changes.parentDivide = ctx.isDivide;
    			if (changed.path) expressiondisplay_changes.path = ctx.path + "," + ctx.i;
    			expressiondisplay.$set(expressiondisplay_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			expressiondisplay.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			expressiondisplay.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			expressiondisplay.$destroy(detaching);
    		}
    	};
    }

    // (18:8) {#if item instanceof Operator}
    function create_if_block$4(ctx) {
    	var current;

    	var operatordisplay = new OperatorDisplay({
    		props: { operator: ctx.item, path: ctx.path + "," + ctx.i },
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			operatordisplay.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(operatordisplay, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var operatordisplay_changes = {};
    			if (changed.expression) operatordisplay_changes.operator = ctx.item;
    			if (changed.path) operatordisplay_changes.path = ctx.path + "," + ctx.i;
    			operatordisplay.$set(operatordisplay_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			operatordisplay.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			operatordisplay.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			operatordisplay.$destroy(detaching);
    		}
    	};
    }

    // (17:4) {#each expression.items as item, i}
    function create_each_block$2(ctx) {
    	var current_block_type_index, if_block, if_block_anchor, current;

    	var if_block_creators = [
    		create_if_block$4,
    		create_if_block_1$3,
    		create_if_block_2$2
    	];

    	var if_blocks = [];

    	function select_block_type(ctx) {
    		if (ctx.item instanceof Operator) return 0;
    		if (ctx.item instanceof Expression) return 1;
    		if (ctx.item instanceof Token) return 2;
    		return -1;
    	}

    	if (~(current_block_type_index = select_block_type(ctx))) {
    		if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
    	}

    	return {
    		c: function create() {
    			if (if_block) if_block.c();
    			if_block_anchor = empty();
    		},

    		m: function mount(target, anchor) {
    			if (~current_block_type_index) if_blocks[current_block_type_index].m(target, anchor);
    			insert(target, if_block_anchor, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var previous_block_index = current_block_type_index;
    			current_block_type_index = select_block_type(ctx);
    			if (current_block_type_index === previous_block_index) {
    				if (~current_block_type_index) if_blocks[current_block_type_index].p(changed, ctx);
    			} else {
    				if (if_block) {
    					group_outros();
    					on_outro(() => {
    						if_blocks[previous_block_index].d(1);
    						if_blocks[previous_block_index] = null;
    					});
    					if_block.o(1);
    					check_outros();
    				}

    				if (~current_block_type_index) {
    					if_block = if_blocks[current_block_type_index];
    					if (!if_block) {
    						if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
    						if_block.c();
    					}
    					if_block.i(1);
    					if_block.m(if_block_anchor.parentNode, if_block_anchor);
    				} else {
    					if_block = null;
    				}
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			if (if_block) if_block.i();
    			current = true;
    		},

    		o: function outro(local) {
    			if (if_block) if_block.o();
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (~current_block_type_index) if_blocks[current_block_type_index].d(detaching);

    			if (detaching) {
    				detach(if_block_anchor);
    			}
    		}
    	};
    }

    function create_fragment$a(ctx) {
    	var div, current;

    	var each_value = ctx.expression.items;

    	var each_blocks = [];

    	for (var i = 0; i < each_value.length; i += 1) {
    		each_blocks[i] = create_each_block$2(get_each_context$2(ctx, each_value, i));
    	}

    	function outro_block(i, detaching, local) {
    		if (each_blocks[i]) {
    			if (detaching) {
    				on_outro(() => {
    					each_blocks[i].d(detaching);
    					each_blocks[i] = null;
    				});
    			}

    			each_blocks[i].o(local);
    		}
    	}

    	return {
    		c: function create() {
    			div = element("div");

    			for (var i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].c();
    			}
    			div.className = "ExpressionDisplay svelte-17mxkg3";
    			toggle_class(div, "parentheses", ctx.expression.items.length > 1 && !ctx.expression.items[1].equals('DIVIDE') && ctx.path.split(",").length > 1 && !ctx.parentDivide);
    			toggle_class(div, "divide", ctx.isDivide);
    			add_location(div, file$a, 13, 0, 384);
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);

    			for (var i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].m(div, null);
    			}

    			current = true;
    		},

    		p: function update(changed, ctx) {
    			if (changed.expression || changed.Operator || changed.path || changed.Expression || changed.isDivide || changed.Token) {
    				each_value = ctx.expression.items;

    				for (var i = 0; i < each_value.length; i += 1) {
    					const child_ctx = get_each_context$2(ctx, each_value, i);

    					if (each_blocks[i]) {
    						each_blocks[i].p(changed, child_ctx);
    						each_blocks[i].i(1);
    					} else {
    						each_blocks[i] = create_each_block$2(child_ctx);
    						each_blocks[i].c();
    						each_blocks[i].i(1);
    						each_blocks[i].m(div, null);
    					}
    				}

    				group_outros();
    				for (; i < each_blocks.length; i += 1) outro_block(i, 1, 1);
    				check_outros();
    			}

    			if ((changed.expression || changed.path || changed.parentDivide)) {
    				toggle_class(div, "parentheses", ctx.expression.items.length > 1 && !ctx.expression.items[1].equals('DIVIDE') && ctx.path.split(",").length > 1 && !ctx.parentDivide);
    			}

    			if (changed.isDivide) {
    				toggle_class(div, "divide", ctx.isDivide);
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			for (var i = 0; i < each_value.length; i += 1) each_blocks[i].i();

    			current = true;
    		},

    		o: function outro(local) {
    			each_blocks = each_blocks.filter(Boolean);
    			for (let i = 0; i < each_blocks.length; i += 1) outro_block(i, 0, 0);

    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}

    			destroy_each(each_blocks, detaching);
    		}
    	};
    }

    function instance$a($$self, $$props, $$invalidate) {
    	

        let { expression, path, parentDivide } = $$props;

    	const writable_props = ['expression', 'path', 'parentDivide'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<ExpressionDisplay> was created with unknown prop '${key}'`);
    	});

    	$$self.$set = $$props => {
    		if ('expression' in $$props) $$invalidate('expression', expression = $$props.expression);
    		if ('path' in $$props) $$invalidate('path', path = $$props.path);
    		if ('parentDivide' in $$props) $$invalidate('parentDivide', parentDivide = $$props.parentDivide);
    	};

    	let isDivide;

    	$$self.$$.update = ($$dirty = { expression: 1 }) => {
    		if ($$dirty.expression) { $$invalidate('isDivide', isDivide = expression.items.length > 1 && expression.items[1].equals('DIVIDE')); }
    	};

    	return { expression, path, parentDivide, isDivide };
    }

    class ExpressionDisplay extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$a, create_fragment$a, safe_not_equal, ["expression", "path", "parentDivide"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.expression === undefined && !('expression' in props)) {
    			console.warn("<ExpressionDisplay> was created without expected prop 'expression'");
    		}
    		if (ctx.path === undefined && !('path' in props)) {
    			console.warn("<ExpressionDisplay> was created without expected prop 'path'");
    		}
    		if (ctx.parentDivide === undefined && !('parentDivide' in props)) {
    			console.warn("<ExpressionDisplay> was created without expected prop 'parentDivide'");
    		}
    	}

    	get expression() {
    		throw new Error("<ExpressionDisplay>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set expression(value) {
    		throw new Error("<ExpressionDisplay>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get path() {
    		throw new Error("<ExpressionDisplay>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set path(value) {
    		throw new Error("<ExpressionDisplay>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get parentDivide() {
    		throw new Error("<ExpressionDisplay>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set parentDivide(value) {
    		throw new Error("<ExpressionDisplay>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/components/History.svelte generated by Svelte v3.5.1 */

    const file$b = "src/components/History.svelte";

    function get_each_context$3(ctx, list, i) {
    	const child_ctx = Object.create(ctx);
    	child_ctx.item = list[i];
    	child_ctx.i = i;
    	return child_ctx;
    }

    // (23:44) 
    function create_if_block_5$1(ctx) {
    	var current;

    	var tokendisplay = new TokenDisplay({
    		props: {
    		token: ctx.item.left,
    		path: "left"
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			tokendisplay.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(tokendisplay, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var tokendisplay_changes = {};
    			if (changed.parsedHistory) tokendisplay_changes.token = ctx.item.left;
    			tokendisplay.$set(tokendisplay_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			tokendisplay.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			tokendisplay.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			tokendisplay.$destroy(detaching);
    		}
    	};
    }

    // (21:49) 
    function create_if_block_4$1(ctx) {
    	var current;

    	var expressiondisplay = new ExpressionDisplay({
    		props: {
    		expression: ctx.item.left,
    		path: "left",
    		parentDivide: false
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			expressiondisplay.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(expressiondisplay, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var expressiondisplay_changes = {};
    			if (changed.parsedHistory) expressiondisplay_changes.expression = ctx.item.left;
    			expressiondisplay.$set(expressiondisplay_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			expressiondisplay.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			expressiondisplay.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			expressiondisplay.$destroy(detaching);
    		}
    	};
    }

    // (19:7) {#if item.left instanceof Operator}
    function create_if_block_3$1(ctx) {
    	var current;

    	var operatordisplay = new OperatorDisplay({
    		props: { operator: ctx.item.left, path: "left" },
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			operatordisplay.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(operatordisplay, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var operatordisplay_changes = {};
    			if (changed.parsedHistory) operatordisplay_changes.operator = ctx.item.left;
    			operatordisplay.$set(operatordisplay_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			operatordisplay.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			operatordisplay.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			operatordisplay.$destroy(detaching);
    		}
    	};
    }

    // (33:45) 
    function create_if_block_2$3(ctx) {
    	var current;

    	var tokendisplay = new TokenDisplay({
    		props: {
    		token: ctx.item.right,
    		path: "right"
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			tokendisplay.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(tokendisplay, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var tokendisplay_changes = {};
    			if (changed.parsedHistory) tokendisplay_changes.token = ctx.item.right;
    			tokendisplay.$set(tokendisplay_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			tokendisplay.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			tokendisplay.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			tokendisplay.$destroy(detaching);
    		}
    	};
    }

    // (31:50) 
    function create_if_block_1$4(ctx) {
    	var current;

    	var expressiondisplay = new ExpressionDisplay({
    		props: {
    		expression: ctx.item.right,
    		path: "right",
    		parentDivide: false
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			expressiondisplay.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(expressiondisplay, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var expressiondisplay_changes = {};
    			if (changed.parsedHistory) expressiondisplay_changes.expression = ctx.item.right;
    			expressiondisplay.$set(expressiondisplay_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			expressiondisplay.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			expressiondisplay.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			expressiondisplay.$destroy(detaching);
    		}
    	};
    }

    // (29:7) {#if item.right instanceof Operator}
    function create_if_block$5(ctx) {
    	var current;

    	var operatordisplay = new OperatorDisplay({
    		props: {
    		operator: ctx.item.right,
    		path: "right"
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			operatordisplay.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(operatordisplay, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var operatordisplay_changes = {};
    			if (changed.parsedHistory) operatordisplay_changes.operator = ctx.item.right;
    			operatordisplay.$set(operatordisplay_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			operatordisplay.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			operatordisplay.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			operatordisplay.$destroy(detaching);
    		}
    	};
    }

    // (15:3) {#each parsedHistory as item, i}
    function create_each_block$3(ctx) {
    	var div5, div4, div0, current_block_type_index, if_block0, t0, div2, div1, t2, div3, current_block_type_index_1, if_block1, t3, current;

    	var if_block_creators = [
    		create_if_block_3$1,
    		create_if_block_4$1,
    		create_if_block_5$1
    	];

    	var if_blocks = [];

    	function select_block_type(ctx) {
    		if (ctx.item.left instanceof Operator) return 0;
    		if (ctx.item.left instanceof Expression) return 1;
    		if (ctx.item.left instanceof Token) return 2;
    		return -1;
    	}

    	if (~(current_block_type_index = select_block_type(ctx))) {
    		if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
    	}

    	var if_block_creators_1 = [
    		create_if_block$5,
    		create_if_block_1$4,
    		create_if_block_2$3
    	];

    	var if_blocks_1 = [];

    	function select_block_type_1(ctx) {
    		if (ctx.item.right instanceof Operator) return 0;
    		if (ctx.item.right instanceof Expression) return 1;
    		if (ctx.item.right instanceof Token) return 2;
    		return -1;
    	}

    	if (~(current_block_type_index_1 = select_block_type_1(ctx))) {
    		if_block1 = if_blocks_1[current_block_type_index_1] = if_block_creators_1[current_block_type_index_1](ctx);
    	}

    	return {
    		c: function create() {
    			div5 = element("div");
    			div4 = element("div");
    			div0 = element("div");
    			if (if_block0) if_block0.c();
    			t0 = space();
    			div2 = element("div");
    			div1 = element("div");
    			div1.textContent = "=";
    			t2 = space();
    			div3 = element("div");
    			if (if_block1) if_block1.c();
    			t3 = space();
    			div0.className = "left svelte-1dka8w3";
    			add_location(div0, file$b, 17, 6, 683);
    			div1.className = "svelte-1dka8w3";
    			add_location(div1, file$b, 26, 26, 1100);
    			div2.className = "equals svelte-1dka8w3";
    			add_location(div2, file$b, 26, 6, 1080);
    			div3.className = "right svelte-1dka8w3";
    			add_location(div3, file$b, 27, 6, 1125);
    			div4.className = "equation svelte-1dka8w3";
    			add_location(div4, file$b, 16, 5, 654);
    			div5.className = "equation-display svelte-1dka8w3";
    			toggle_class(div5, "current", ctx.i===ctx.$history.index);
    			add_location(div5, file$b, 15, 4, 583);
    		},

    		m: function mount(target, anchor) {
    			insert(target, div5, anchor);
    			append(div5, div4);
    			append(div4, div0);
    			if (~current_block_type_index) if_blocks[current_block_type_index].m(div0, null);
    			append(div4, t0);
    			append(div4, div2);
    			append(div2, div1);
    			append(div4, t2);
    			append(div4, div3);
    			if (~current_block_type_index_1) if_blocks_1[current_block_type_index_1].m(div3, null);
    			append(div5, t3);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var previous_block_index = current_block_type_index;
    			current_block_type_index = select_block_type(ctx);
    			if (current_block_type_index === previous_block_index) {
    				if (~current_block_type_index) if_blocks[current_block_type_index].p(changed, ctx);
    			} else {
    				if (if_block0) {
    					group_outros();
    					on_outro(() => {
    						if_blocks[previous_block_index].d(1);
    						if_blocks[previous_block_index] = null;
    					});
    					if_block0.o(1);
    					check_outros();
    				}

    				if (~current_block_type_index) {
    					if_block0 = if_blocks[current_block_type_index];
    					if (!if_block0) {
    						if_block0 = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
    						if_block0.c();
    					}
    					if_block0.i(1);
    					if_block0.m(div0, null);
    				} else {
    					if_block0 = null;
    				}
    			}

    			var previous_block_index_1 = current_block_type_index_1;
    			current_block_type_index_1 = select_block_type_1(ctx);
    			if (current_block_type_index_1 === previous_block_index_1) {
    				if (~current_block_type_index_1) if_blocks_1[current_block_type_index_1].p(changed, ctx);
    			} else {
    				if (if_block1) {
    					group_outros();
    					on_outro(() => {
    						if_blocks_1[previous_block_index_1].d(1);
    						if_blocks_1[previous_block_index_1] = null;
    					});
    					if_block1.o(1);
    					check_outros();
    				}

    				if (~current_block_type_index_1) {
    					if_block1 = if_blocks_1[current_block_type_index_1];
    					if (!if_block1) {
    						if_block1 = if_blocks_1[current_block_type_index_1] = if_block_creators_1[current_block_type_index_1](ctx);
    						if_block1.c();
    					}
    					if_block1.i(1);
    					if_block1.m(div3, null);
    				} else {
    					if_block1 = null;
    				}
    			}

    			if (changed.$history) {
    				toggle_class(div5, "current", ctx.i===ctx.$history.index);
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			if (if_block0) if_block0.i();
    			if (if_block1) if_block1.i();
    			current = true;
    		},

    		o: function outro(local) {
    			if (if_block0) if_block0.o();
    			if (if_block1) if_block1.o();
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div5);
    			}

    			if (~current_block_type_index) if_blocks[current_block_type_index].d();
    			if (~current_block_type_index_1) if_blocks_1[current_block_type_index_1].d();
    		}
    	};
    }

    function create_fragment$b(ctx) {
    	var div1, div0, current;

    	var each_value = ctx.parsedHistory;

    	var each_blocks = [];

    	for (var i = 0; i < each_value.length; i += 1) {
    		each_blocks[i] = create_each_block$3(get_each_context$3(ctx, each_value, i));
    	}

    	function outro_block(i, detaching, local) {
    		if (each_blocks[i]) {
    			if (detaching) {
    				on_outro(() => {
    					each_blocks[i].d(detaching);
    					each_blocks[i] = null;
    				});
    			}

    			each_blocks[i].o(local);
    		}
    	}

    	return {
    		c: function create() {
    			div1 = element("div");
    			div0 = element("div");

    			for (var i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].c();
    			}
    			div0.className = "stack svelte-1dka8w3";
    			add_location(div0, file$b, 13, 4, 507);
    			div1.className = "History svelte-1dka8w3";
    			add_location(div1, file$b, 12, 0, 481);
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert(target, div1, anchor);
    			append(div1, div0);

    			for (var i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].m(div0, null);
    			}

    			add_binding_callback(() => ctx.div0_binding(div0, null));
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			if (changed.$history || changed.parsedHistory || changed.Operator || changed.Expression || changed.Token) {
    				each_value = ctx.parsedHistory;

    				for (var i = 0; i < each_value.length; i += 1) {
    					const child_ctx = get_each_context$3(ctx, each_value, i);

    					if (each_blocks[i]) {
    						each_blocks[i].p(changed, child_ctx);
    						each_blocks[i].i(1);
    					} else {
    						each_blocks[i] = create_each_block$3(child_ctx);
    						each_blocks[i].c();
    						each_blocks[i].i(1);
    						each_blocks[i].m(div0, null);
    					}
    				}

    				group_outros();
    				for (; i < each_blocks.length; i += 1) outro_block(i, 1, 1);
    				check_outros();
    			}

    			if (changed.items) {
    				ctx.div0_binding(null, div0);
    				ctx.div0_binding(div0, null);
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			for (var i = 0; i < each_value.length; i += 1) each_blocks[i].i();

    			current = true;
    		},

    		o: function outro(local) {
    			each_blocks = each_blocks.filter(Boolean);
    			for (let i = 0; i < each_blocks.length; i += 1) outro_block(i, 0, 0);

    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div1);
    			}

    			destroy_each(each_blocks, detaching);

    			ctx.div0_binding(null, div0);
    		}
    	};
    }

    function instance$b($$self, $$props, $$invalidate) {
    	let $history;

    	validate_store(history, 'history');
    	subscribe($$self, history, $$value => { $history = $$value; $$invalidate('$history', $history); });

    	
    	let ref;

    	function div0_binding($$node, check) {
    		ref = $$node;
    		$$invalidate('ref', ref);
    	}

    	let parsedHistory;

    	$$self.$$.update = ($$dirty = { $history: 1 }) => {
    		if ($$dirty.$history) { $$invalidate('parsedHistory', parsedHistory = $history.all.map(item => parseGrammar(item))); }
    	};

    	return {
    		ref,
    		parsedHistory,
    		$history,
    		div0_binding
    	};
    }

    class History extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$b, create_fragment$b, safe_not_equal, []);
    	}
    }

    /* src/components/Alien.svelte generated by Svelte v3.5.1 */

    const file$c = "src/components/Alien.svelte";

    function create_fragment$c(ctx) {
    	var div, img0, t, img1;

    	return {
    		c: function create() {
    			div = element("div");
    			img0 = element("img");
    			t = space();
    			img1 = element("img");
    			img0.className = "display alien-body svelte-d261kf";
    			img0.src = ctx.body;
    			img0.alt = "";
    			add_location(img0, file$c, 45, 4, 1373);
    			img1.className = "display alien-face svelte-d261kf";
    			img1.src = ctx.face;
    			img1.alt = "";
    			add_location(img1, file$c, 46, 4, 1428);
    			div.className = "Alien svelte-d261kf";
    			add_location(div, file$c, 44, 0, 1349);
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);
    			append(div, img0);
    			append(div, t);
    			append(div, img1);
    		},

    		p: function update(changed, ctx) {
    			if (changed.body) {
    				img0.src = ctx.body;
    			}

    			if (changed.face) {
    				img1.src = ctx.face;
    			}
    		},

    		i: noop,
    		o: noop,

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}
    		}
    	};
    }

    function instance$c($$self, $$props, $$invalidate) {
    	let { state } = $$props;
        let prevState;
        const stateMap = {
            default: {
                body: './images/lynnette-alien-body-neutral.png',
                face: './images/lynnette-alien-face-neutral.png',
            },
            error: {
                body: './images/lynnette-alien-body-point.png',
                face: './images/lynnette-alien-face-problem.png',
            },
            success: {
                body: './images/lynnette-alien-body-excited.png',
                face: './images/lynnette-alien-face-excited.png',
            }
        };

        const audioFiles = {
            error: {file: './audio/hmm.wav', volume: 0.5},
            success: {file: './audio/haHa.wav', volume: 0.5},
        };
        var audioSource;
        onMount(() => {
    		audioSource = new Audio('./audio/hmm.wav');
        });
        function playSound(file, vol) {
            audioSource.src = file;        audioSource.volume = vol;        audioSource.play();
        }
        beforeUpdate(() => {
            if (state && state !== prevState && state !== 'default') {
                playSound(audioFiles[state].file, audioFiles[state].volume);
            }
            prevState = state;
        });

    	const writable_props = ['state'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<Alien> was created with unknown prop '${key}'`);
    	});

    	$$self.$set = $$props => {
    		if ('state' in $$props) $$invalidate('state', state = $$props.state);
    	};

    	let body, face;

    	$$self.$$.update = ($$dirty = { state: 1 }) => {
    		if ($$dirty.state) { $$invalidate('body', body = stateMap[state] ? stateMap[state].body : stateMap.default.body); }
    		if ($$dirty.state) { $$invalidate('face', face = stateMap[state] ? stateMap[state].face : stateMap.default.face); }
    	};

    	return { state, body, face };
    }

    class Alien extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$c, create_fragment$c, safe_not_equal, ["state"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.state === undefined && !('state' in props)) {
    			console.warn("<Alien> was created without expected prop 'state'");
    		}
    	}

    	get state() {
    		throw new Error("<Alien>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set state(value) {
    		throw new Error("<Alien>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    const initial$1 = {
        error: null,
        hint: null,
        success: null,
        side: null,
    };

    function createMessageManager() {
    	const { subscribe, update, set } = writable(initial$1);

        return {
            subscribe,
            setError: message => update(state => {
                return Object.assign({}, state, {error: {message: message}})
            }),
            setHint: message => update(state => {
                return Object.assign({}, state, {hint: {message: message}})
            }),
            setSuccess: message => update(state => {
                return Object.assign({}, state, {success: {message: message}})
            }),
            setSide: side => update(state => {
                return Object.assign({}, state, {side: side});
            }),
            reset: () => set(initial$1),
        }
    }

    const messageManager = createMessageManager();

    /* src/App.svelte generated by Svelte v3.5.1 */

    const file$d = "src/App.svelte";

    // (44:4) {#if $history.current}
    function create_if_block_5$2(ctx) {
    	var current;

    	var history_1 = new History({ $$inline: true });

    	return {
    		c: function create() {
    			history_1.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(history_1, target, anchor);
    			current = true;
    		},

    		i: function intro(local) {
    			if (current) return;
    			history_1.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			history_1.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			history_1.$destroy(detaching);
    		}
    	};
    }

    // (49:3) {#if $messageManager.error || $messageManager.hint || $messageManager.success}
    function create_if_block_1$5(ctx) {
    	var div, t0, t1;

    	var if_block0 = (ctx.$messageManager.error) && create_if_block_4$2(ctx);

    	var if_block1 = (ctx.$messageManager.hint) && create_if_block_3$2(ctx);

    	var if_block2 = (ctx.$messageManager.success) && create_if_block_2$4(ctx);

    	return {
    		c: function create() {
    			div = element("div");
    			if (if_block0) if_block0.c();
    			t0 = space();
    			if (if_block1) if_block1.c();
    			t1 = space();
    			if (if_block2) if_block2.c();
    			div.className = "message svelte-x7w9vv";
    			add_location(div, file$d, 49, 4, 1884);
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);
    			if (if_block0) if_block0.m(div, null);
    			append(div, t0);
    			if (if_block1) if_block1.m(div, null);
    			append(div, t1);
    			if (if_block2) if_block2.m(div, null);
    		},

    		p: function update(changed, ctx) {
    			if (ctx.$messageManager.error) {
    				if (if_block0) {
    					if_block0.p(changed, ctx);
    				} else {
    					if_block0 = create_if_block_4$2(ctx);
    					if_block0.c();
    					if_block0.m(div, t0);
    				}
    			} else if (if_block0) {
    				if_block0.d(1);
    				if_block0 = null;
    			}

    			if (ctx.$messageManager.hint) {
    				if (if_block1) {
    					if_block1.p(changed, ctx);
    				} else {
    					if_block1 = create_if_block_3$2(ctx);
    					if_block1.c();
    					if_block1.m(div, t1);
    				}
    			} else if (if_block1) {
    				if_block1.d(1);
    				if_block1 = null;
    			}

    			if (ctx.$messageManager.success) {
    				if (if_block2) {
    					if_block2.p(changed, ctx);
    				} else {
    					if_block2 = create_if_block_2$4(ctx);
    					if_block2.c();
    					if_block2.m(div, null);
    				}
    			} else if (if_block2) {
    				if_block2.d(1);
    				if_block2 = null;
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}

    			if (if_block0) if_block0.d();
    			if (if_block1) if_block1.d();
    			if (if_block2) if_block2.d();
    		}
    	};
    }

    // (51:5) {#if $messageManager.error}
    function create_if_block_4$2(ctx) {
    	var div, t_value = ctx.$messageManager.error.message, t;

    	return {
    		c: function create() {
    			div = element("div");
    			t = text(t_value);
    			div.className = "error svelte-x7w9vv";
    			add_location(div, file$d, 51, 6, 1945);
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);
    			append(div, t);
    		},

    		p: function update(changed, ctx) {
    			if ((changed.$messageManager) && t_value !== (t_value = ctx.$messageManager.error.message)) {
    				set_data(t, t_value);
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}
    		}
    	};
    }

    // (54:5) {#if $messageManager.hint}
    function create_if_block_3$2(ctx) {
    	var div, t_value = ctx.$messageManager.hint.message, t;

    	return {
    		c: function create() {
    			div = element("div");
    			t = text(t_value);
    			div.className = "hint svelte-x7w9vv";
    			add_location(div, file$d, 54, 6, 2051);
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);
    			append(div, t);
    		},

    		p: function update(changed, ctx) {
    			if ((changed.$messageManager) && t_value !== (t_value = ctx.$messageManager.hint.message)) {
    				set_data(t, t_value);
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}
    		}
    	};
    }

    // (57:5) {#if $messageManager.success}
    function create_if_block_2$4(ctx) {
    	var div, t_value = ctx.$messageManager.success.message, t;

    	return {
    		c: function create() {
    			div = element("div");
    			t = text(t_value);
    			div.className = "success svelte-x7w9vv";
    			add_location(div, file$d, 57, 6, 2158);
    		},

    		m: function mount(target, anchor) {
    			insert(target, div, anchor);
    			append(div, t);
    		},

    		p: function update(changed, ctx) {
    			if ((changed.$messageManager) && t_value !== (t_value = ctx.$messageManager.success.message)) {
    				set_data(t, t_value);
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div);
    			}
    		}
    	};
    }

    // (77:3) {#if $history.current}
    function create_if_block$6(ctx) {
    	var current;

    	var previewequation = new PreviewEquation({
    		props: {
    		state: parseGrammar(ctx.$history.current),
    		draft: parseGrammar(ctx.$draftEquation),
    		error: ctx.$messageManager.side
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			previewequation.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(previewequation, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var previewequation_changes = {};
    			if (changed.parseGrammar || changed.$history) previewequation_changes.state = parseGrammar(ctx.$history.current);
    			if (changed.parseGrammar || changed.$draftEquation) previewequation_changes.draft = parseGrammar(ctx.$draftEquation);
    			if (changed.$messageManager) previewequation_changes.error = ctx.$messageManager.side;
    			previewequation.$set(previewequation_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			previewequation.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			previewequation.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			previewequation.$destroy(detaching);
    		}
    	};
    }

    function create_fragment$d(ctx) {
    	var div11, div0, button0, t1, button1, t3, button2, t5, input, t6, button3, t8, div5, div3, div1, t10, div2, t11, div4, t12, t13, div7, button4, t15, div6, button5, t17, div10, div8, t18, div9, current, dispose;

    	var if_block0 = (ctx.$history.current) && create_if_block_5$2();

    	var alien = new Alien({
    		props: { state: ctx.$messageManager.success ? 'success' : ctx.$messageManager.error ? 'error' : 'default' },
    		$$inline: true
    	});

    	var if_block1 = (ctx.$messageManager.error || ctx.$messageManager.hint || ctx.$messageManager.success) && create_if_block_1$5(ctx);

    	var operatorbox = new OperatorBox({
    		props: { operators: ctx.operators },
    		$$inline: true
    	});

    	var if_block2 = (ctx.$history.current) && create_if_block$6(ctx);

    	return {
    		c: function create() {
    			div11 = element("div");
    			div0 = element("div");
    			button0 = element("button");
    			button0.textContent = "Toggle Error";
    			t1 = space();
    			button1 = element("button");
    			button1.textContent = "Toggle Success";
    			t3 = space();
    			button2 = element("button");
    			button2.textContent = "Undo";
    			t5 = space();
    			input = element("input");
    			t6 = space();
    			button3 = element("button");
    			button3.textContent = "Set Eqn";
    			t8 = space();
    			div5 = element("div");
    			div3 = element("div");
    			div1 = element("div");
    			div1.textContent = "History";
    			t10 = space();
    			div2 = element("div");
    			if (if_block0) if_block0.c();
    			t11 = space();
    			div4 = element("div");
    			alien.$$.fragment.c();
    			t12 = space();
    			if (if_block1) if_block1.c();
    			t13 = space();
    			div7 = element("div");
    			button4 = element("button");
    			button4.textContent = "Undo";
    			t15 = space();
    			div6 = element("div");
    			button5 = element("button");
    			button5.textContent = "Done";
    			t17 = space();
    			div10 = element("div");
    			div8 = element("div");
    			operatorbox.$$.fragment.c();
    			t18 = space();
    			div9 = element("div");
    			if (if_block2) if_block2.c();
    			button0.className = "svelte-x7w9vv";
    			add_location(button0, file$d, 33, 2, 1042);
    			button1.className = "svelte-x7w9vv";
    			add_location(button1, file$d, 34, 2, 1183);
    			button2.className = "svelte-x7w9vv";
    			add_location(button2, file$d, 35, 2, 1333);
    			attr(input, "type", "text");
    			input.className = "svelte-x7w9vv";
    			add_location(input, file$d, 36, 2, 1373);
    			button3.className = "svelte-x7w9vv";
    			add_location(button3, file$d, 37, 2, 1412);
    			div0.className = "testing svelte-x7w9vv";
    			add_location(div0, file$d, 32, 1, 1018);
    			div1.className = "history-title svelte-x7w9vv";
    			add_location(div1, file$d, 41, 3, 1531);
    			div2.className = "history-items svelte-x7w9vv";
    			add_location(div2, file$d, 42, 3, 1575);
    			div3.className = "history svelte-x7w9vv";
    			add_location(div3, file$d, 40, 2, 1506);
    			div4.className = "alien svelte-x7w9vv";
    			add_location(div4, file$d, 46, 2, 1676);
    			div5.className = "sidebar svelte-x7w9vv";
    			add_location(div5, file$d, 39, 1, 1482);
    			button4.className = "button undo svelte-x7w9vv";
    			toggle_class(button4, "active", ctx.$messageManager.error);
    			add_location(button4, file$d, 64, 2, 2292);
    			button5.className = "button button-done svelte-x7w9vv";
    			add_location(button5, file$d, 67, 3, 2502);
    			div6.className = "bottom svelte-x7w9vv";
    			add_location(div6, file$d, 66, 2, 2478);
    			div7.className = "buttons svelte-x7w9vv";
    			add_location(div7, file$d, 63, 1, 2268);
    			div8.className = "operators svelte-x7w9vv";
    			add_location(div8, file$d, 72, 2, 2670);
    			div9.className = "equation-container svelte-x7w9vv";
    			toggle_class(div9, "disable", ctx.$messageManager.error);
    			add_location(div9, file$d, 75, 2, 2745);
    			div10.className = "content svelte-x7w9vv";
    			add_location(div10, file$d, 71, 1, 2646);
    			div11.className = "root svelte-x7w9vv";
    			add_location(div11, file$d, 31, 0, 998);

    			dispose = [
    				listen(button0, "click", ctx.click_handler),
    				listen(button1, "click", ctx.click_handler_1),
    				listen(button2, "click", undo),
    				listen(input, "input", ctx.input_input_handler),
    				listen(button3, "click", ctx.click_handler_2),
    				listen(button4, "click", undo),
    				listen(button5, "click", done)
    			];
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert(target, div11, anchor);
    			append(div11, div0);
    			append(div0, button0);
    			append(div0, t1);
    			append(div0, button1);
    			append(div0, t3);
    			append(div0, button2);
    			append(div0, t5);
    			append(div0, input);

    			input.value = ctx.val;

    			append(div0, t6);
    			append(div0, button3);
    			append(div11, t8);
    			append(div11, div5);
    			append(div5, div3);
    			append(div3, div1);
    			append(div3, t10);
    			append(div3, div2);
    			if (if_block0) if_block0.m(div2, null);
    			append(div5, t11);
    			append(div5, div4);
    			mount_component(alien, div4, null);
    			append(div4, t12);
    			if (if_block1) if_block1.m(div4, null);
    			append(div11, t13);
    			append(div11, div7);
    			append(div7, button4);
    			append(div7, t15);
    			append(div7, div6);
    			append(div6, button5);
    			append(div11, t17);
    			append(div11, div10);
    			append(div10, div8);
    			mount_component(operatorbox, div8, null);
    			append(div10, t18);
    			append(div10, div9);
    			if (if_block2) if_block2.m(div9, null);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			if (changed.val && (input.value !== ctx.val)) input.value = ctx.val;

    			if (ctx.$history.current) {
    				if (!if_block0) {
    					if_block0 = create_if_block_5$2();
    					if_block0.c();
    					if_block0.i(1);
    					if_block0.m(div2, null);
    				} else {
    									if_block0.i(1);
    				}
    			} else if (if_block0) {
    				group_outros();
    				on_outro(() => {
    					if_block0.d(1);
    					if_block0 = null;
    				});

    				if_block0.o(1);
    				check_outros();
    			}

    			var alien_changes = {};
    			if (changed.$messageManager) alien_changes.state = ctx.$messageManager.success ? 'success' : ctx.$messageManager.error ? 'error' : 'default';
    			alien.$set(alien_changes);

    			if (ctx.$messageManager.error || ctx.$messageManager.hint || ctx.$messageManager.success) {
    				if (if_block1) {
    					if_block1.p(changed, ctx);
    				} else {
    					if_block1 = create_if_block_1$5(ctx);
    					if_block1.c();
    					if_block1.m(div4, null);
    				}
    			} else if (if_block1) {
    				if_block1.d(1);
    				if_block1 = null;
    			}

    			if (changed.$messageManager) {
    				toggle_class(button4, "active", ctx.$messageManager.error);
    			}

    			var operatorbox_changes = {};
    			if (changed.operators) operatorbox_changes.operators = ctx.operators;
    			operatorbox.$set(operatorbox_changes);

    			if (ctx.$history.current) {
    				if (if_block2) {
    					if_block2.p(changed, ctx);
    					if_block2.i(1);
    				} else {
    					if_block2 = create_if_block$6(ctx);
    					if_block2.c();
    					if_block2.i(1);
    					if_block2.m(div9, null);
    				}
    			} else if (if_block2) {
    				group_outros();
    				on_outro(() => {
    					if_block2.d(1);
    					if_block2 = null;
    				});

    				if_block2.o(1);
    				check_outros();
    			}

    			if (changed.$messageManager) {
    				toggle_class(div9, "disable", ctx.$messageManager.error);
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			if (if_block0) if_block0.i();

    			alien.$$.fragment.i(local);

    			operatorbox.$$.fragment.i(local);

    			if (if_block2) if_block2.i();
    			current = true;
    		},

    		o: function outro(local) {
    			if (if_block0) if_block0.o();
    			alien.$$.fragment.o(local);
    			operatorbox.$$.fragment.o(local);
    			if (if_block2) if_block2.o();
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(div11);
    			}

    			if (if_block0) if_block0.d();

    			alien.$destroy();

    			if (if_block1) if_block1.d();

    			operatorbox.$destroy();

    			if (if_block2) if_block2.d();
    			run_all(dispose);
    		}
    	};
    }

    function undo() {
    	history.step(-1);
    	messageManager.reset();
    }

    function done() {
    	CTATCommShell.commShell.processDone("Test");
    }

    function instance$d($$self, $$props, $$invalidate) {
    	let $messageManager, $history, $draftEquation;

    	validate_store(messageManager, 'messageManager');
    	subscribe($$self, messageManager, $$value => { $messageManager = $$value; $$invalidate('$messageManager', $messageManager); });
    	validate_store(history, 'history');
    	subscribe($$self, history, $$value => { $history = $$value; $$invalidate('$history', $history); });
    	validate_store(draftEquation, 'draftEquation');
    	subscribe($$self, draftEquation, $$value => { $draftEquation = $$value; $$invalidate('$draftEquation', $draftEquation); });

    	
    	let operators = [new Operator('PLUS'), new Operator('MINUS'), new Operator('TIMES'), new Operator('DIVIDE')];
    	window.test = false;

    	let val = '';
    	window.setEqn = newEqn => {
    		history.reset();
    		history.push(window.parse.algParse(newEqn));
    	};

    	function click_handler() {if ($messageManager.error) messageManager.reset(); else messageManager.setError('Error');}

    	function click_handler_1() {if ($messageManager.success) messageManager.reset(); else messageManager.setSuccess('Success!');}

    	function input_input_handler() {
    		val = this.value;
    		$$invalidate('val', val);
    	}

    	function click_handler_2() {
    		return window.setEqn(val);
    	}

    	let test;

    	test = window.test;

    	return {
    		operators,
    		val,
    		window,
    		$messageManager,
    		$history,
    		$draftEquation,
    		click_handler,
    		click_handler_1,
    		input_input_handler,
    		click_handler_2
    	};
    }

    class App extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$d, create_fragment$d, safe_not_equal, []);
    	}
    }

    /**-----------------------------------------------------------------------------
     $Author: sewall $
     $Date: 2016-12-15 12:33:36 -0500 (Thu, 15 Dec 2016) $
     $HeadURL: svn://pact-cvs.pact.cs.cmu.edu/usr5/local/svnroot/AuthoringTools/trunk/HTML5/ctatloader.js $
     $Revision: 24444 $

     -
     License:
     -
     ChangeLog:
     -
     Notes:

     */
    console.log("Starting ctatloader ...");
    if (frameElement && typeof (frameElement.getAttribute) == "function") {
    	let dpAttr = frameElement.getAttribute('data-params');
    	let dpObj = null;
    	if (dpAttr && (dpObj = JSON.parse(dpAttr)) && dpObj.hasOwnProperty('CTATTarget')) {
    		var CTATTarget = dpObj['CTATTarget'];
    	}
    }

    // Set CTATTarget to Default if not already set.
    if (typeof (CTATTarget) == "undefined" || !CTATTarget) {
    	console.log("CTATTarget not defined, setting it to 'Default' ...");
    	var CTATTarget = "Default";
    }
    else {
    	console.log("CTATTarget already defined at top of ctatloader, set to: " + CTATTarget);
    }

    console.log("Double checking target: " + CTATTarget);

    function startCTAT() {
    	initTutor();

    	// Once all the CTAT code has been loaded allow developers to activate custom code

    	if (window.hasOwnProperty('ctatOnload')) {
    		window['ctatOnload']();
    	}
    	else {
    		console.log("Warning: window.ctatOnload is not available");
    	}
    }
    /**
     *
     */
    function initOnload() {
    	console.log("initOnload ()");

    	//>-------------------------------------------------------------------------

    	if (CTATLMS.is.Authoring() || CTATTarget === "AUTHORING") {
    		console.log('(CTATTarget=="AUTHORING")');

    		var session = CTATConfiguration.get('session_id');
    		var port = CTATConfiguration.get('remoteSocketPort');
    		if (window.location.search) {
    			var p = /[?&;]port=(\d+)/i.exec(window.location.search);
    			if (p && p.length >= 2) {
    				port = decodeURIComponent(p[1].replace(/\+/g, ' '));
    			}
    			var s = /[?&;]session=([^&]*)/i.exec(window.location.search);
    			if (s && s.length >= 2) {
    				session = decodeURIComponent(s[1].replace(/\+/g, ' '));
    			}
    		}
    		CTATConfiguration.set('tutoring_service_communication', 'websocket');
    		CTATConfiguration.set('user_guid', 'author');
    		CTATConfiguration.set('question_file', '');
    		CTATConfiguration.set('session_id', session);
    		CTATConfiguration.set('remoteSocketPort', port);
    		CTATConfiguration.set('remoteSocketURL', "127.0.0.1");

    		startCTAT();
    		return;
    	}

    	//>-------------------------------------------------------------------------	

    	if (CTATLMS.is.OLI()) {
    		// Do nothing as OLI will call initTutor and ctatOnload.
    		// Should probably move to a similar mechanism as XBlock
    		console.log("CTATTarget=='OLI'");
    		return;
    	}

    	//>-------------------------------------------------------------------------	

    	if (CTATLMS.is.SCORM()) {
    		console.log("CTATTarget=='SCORM'");

    		CTATLMS.init.SCORM();
    		// Initialize our own code ...
    		startCTAT();
    		return;
    	}

    	//>-------------------------------------------------------------------------	

    	if (CTATLMS.is.Assistments()) {
    		console.log("CTATTarget=='ASSISTMENTS'");

    		iframeLoaded(); // Assistments specific call

    		// Initialize our own code ...
    		startCTAT();
    		return;
    	}

    	//>-------------------------------------------------------------------------	

    	if (CTATLMS.is.XBlock()) {
    		console.log("CTATTarget=='XBlock'");

    		CTATLMS.init.XBlock();
    		// listen for configuration block
    		window.addEventListener("message", function (event) {
    			console.log('recieved message', event.origin, document.referrer, event.data);
    			if (!document.referrer && event.origin !== (new URl(document.referrer)).origin) {
    				console.log("Message not from valid source:", event.origin,
    					"Expected:", document.referrer); // TODO: remove expected
    				return;
    			}
    			if (!CTATTutor.tutorInitialized && 'question_file' in event.data) { // looks like we have configuration
    				initTutor(event.data);
    				if (window.hasOwnProperty('ctatOnload')) {
    					window['ctatOnload']();
    				}
    			}
    			// Should probably remove listener once configuration is received
    			// so that malicious hackers do not cause multiple initializations.
    		});
    		return;
    	}

    	//>-------------------------------------------------------------------------	

    	/*
    	* The target CTAT is synonymous with TutorShop. You can use this target outside of
    	* TutorShop if you use the same directory structure for the css, js and brd files
    	*/
    	if (CTATTarget == "CTAT" || CTATTarget == "LTI" || CTATLMS.is.TutorShop()) {
    		console.log("CTATTarget=='CTAT'");

    		CTATLMS.init.TutorShop();
    		startCTAT();

    		return;
    	}

    	//>-------------------------------------------------------------------------	

    	/*
    	* This target is available to you if you would like to either develop your own
    	* Learner Management System or would like to test and run your tutor standalone.
    	* NOTE! This version will NOT call initTutor since that is the responsibility
    	* of the author in this case.
    	*/
    	if (CTATTarget == "Default") {
    		console.log("CTATTarget=='Default'");

    		// Once all the CTAT code has been loaded allow developers to activate custom code

    		if (window.hasOwnProperty('ctatOnload')) {
    			window['ctatOnload']();
    		}
    		else {
    			console.log("Warning: window.ctatOnload is not available, running initTutor()");
    			initTutor();
    		}

    		return;
    	}

    	//>-------------------------------------------------------------------------	
    }

    /**
     *
     */
    const parse$1 = new CTATAlgebraParser();
    if (window.jQuery) {
    	$(function () {
    		CTATScrim.scrim.waitScrimUp();
    		console.log("$(window).load(" + CTATTarget + ")");
    		initOnload();
    		CTATCommShell.commShell.assignDoneProcessor((input, finish) => {
    			messageManager.setSuccess("Yay!");
    			setTimeout(() => {
    				finish();
    			}, 5000);
    		});
    		CTATCommShell.commShell.addGlobalEventListener({
    			processCommShellEvent: (evt, msg) => {
    				console.log(evt, msg);
    				switch (evt) {
    					case "InterfaceAction":
    						if (msg && !(typeof msg === 'string' || msg instanceof String)) {
    							var sai = msg.getSAI();
    							console.log("INTERFACE ACTION:", sai.getInput());
    							var input = sai.getInput();
    							// history.push(parse.algParse(input));
    							draftEquation.set(parse$1.algParse(input));
    							draftEquation.apply(false);
    						}
    						break;
    					case "CorrectAction":
    						console.log("CorrectAction", msg);
    						break;
    					case "InCorrectAction":
    						console.log("InCorrectAction", msg);
    						var sai = msg.getSAI();
    						console.log("INTERFACE ACTION:", sai.getSelection());
    						messageManager.setSide(sai.getSelection());
    						messageManager.setError("Default Error");
    						break;
    					case "BuggyMessage":
    						console.log("BuggyMessage", msg);
    						messageManager.setError(msg.getBuggyMsg());
    						console.log(msg.getBuggyMsg());
    						break;
    					default:
    						break;
    				}
    			}
    		});
    	});
    }
    else {
    	console.log("Error: JQuery not available, can not execute $(window).on('load',...)");
    }

    // foo();
    window.drag = {};
    window.drop = {};
    var app = new App({
    	target: document.body
    });

    return app;

}());
//# sourceMappingURL=bundle.js.map
